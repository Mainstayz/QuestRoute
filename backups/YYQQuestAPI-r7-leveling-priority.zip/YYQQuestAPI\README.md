# YYQ 角色任务 API

《魔兽世界：无限》只读插件，读取当前登录角色任务日志中的全部任务，包括折叠分类下的任务、日志中可枚举的隐藏任务，以及完成后尚未交付的任务。不包含已交付的历史任务和尚未接取的任务。

当前修订为 **apiRevision=7**，按客户端难度与奖励经验优先安排适合升级的任务，替代单纯低等级加权；保留大/小地图路线、当前地区过滤、1号目标稳定和200码任务归组。原有 `get_quests` 保持 schemaVersion=1、默认100的分页和字段兼容，提供可选原生 `tag={id,name,isElite?,tradeskillLineID?}`。另外提供玩家状态、原生任务POI、任务详情和可选QuestieDB实体查询，数据结构继续使用schemaVersion=1。

原生数据决定当前任务状态、进度及目标行为；QuestieDB补充数据独立放置并标记来源。无需安装QuestieDB即可使用原生接口。

## 从 YYQ 调用

使用无限工坊的 `mcp__wuxian__call`：

```json
{
  "addon": "YYQQuestAPI",
  "name": "get_quests",
  "args": {}
}
```

默认返回最多 100 个任务及其目标进度。读取更多任务时，使用结果的 `nextOffset` 继续，直到 `hasMore` 为 false。

分页或只取基本信息：

```json
{
  "addon": "YYQQuestAPI",
  "name": "get_quests",
  "args": {
    "offset": 0,
    "limit": 10,
    "includeObjectives": false
  }
}
```

参数：

| 字段 | 默认值 | 含义 |
| --- | --- | --- |
| `offset` | `0` | 从 0 开始的任务偏移，非负整数 |
| `limit` | `100` | 每页数量，1 至 100 的整数 |
| `includeObjectives` | `true` | 是否附带目标文字、类型、已完成数量和所需数量 |

## 其他插件中的 Lua 调用

在依赖中声明 `YYQQuestAPI`，并在它加载后调用：

```lua
local api = WoWBridgeNS and WoWBridgeNS.YYQQuestAPI
if api and api.GetQuests then
    local result = api.GetQuests({ limit = 100 })
    if result.ok then
        for _, quest in ipairs(result.quests) do
            print(quest.questID, quest.title, quest.status)
        end
    end
end
```

游戏内输入 `/yyqquestapi`，会在自己的聊天窗口显示当前任务列表。

## 返回结构

`call` 的返回结果包在 `result` 中；Lua 直接调用则直接得到下列结构。

```json
{
  "ok": true,
  "schemaVersion": 1,
  "scope": "active_quest_log",
  "character": { "name": "擎天", "realm": "CN1 Realm 10 RP" },
  "total": 22,
  "reportedTotal": 22,
  "logComplete": true,
  "offset": 0,
  "limit": 1,
  "count": 1,
  "hasMore": true,
  "nextOffset": 1,
  "quests": [
    {
      "questID": 1491,
      "title": "智慧饮料",
      "category": "哀嚎洞穴",
      "logIndex": 2,
      "level": 18,
      "suggestedGroup": 0,
      "frequency": 0,
      "classification": 7,
      "isHidden": false,
      "isTask": false,
      "isStory": false,
      "isComplete": false,
      "isFailed": false,
      "readyForTurnIn": false,
      "status": "in_progress",
      "objectivesLoaded": true,
      "objectives": [
        {
          "index": 1,
          "text": "0/6 哀嚎香精",
          "type": "item",
          "objectiveType": 1,
          "finished": false,
          "numFulfilled": 0,
          "numRequired": 6
        }
      ]
    }
  ]
}
```

- `total` 是枚举到的任务数，`reportedTotal` 是客户端报告的任务数；`logComplete` 表示两者一致，和是否还有下一页无关。
- `status` 为 `in_progress`（进行中）、`ready_for_turn_in`（可交付）、`complete`（目标完成但客户端尚未标为可交付）或 `failed`（失败）。
- `objectivesLoaded` 表示客户端是否返回了目标表；不保证所有目标文字都已经包含物品或怪物名称。文字和数量按客户端原样返回，目标是否完成以 `finished` 为准，不以数量自行推断。
- `includeObjectives=false` 时不返回 `objectives` 和 `objectivesLoaded`。最后一页不包含 `nextOffset`。不存在的可选字段省略。
- 每次调用实时读取。分页期间玩家接取或交付任务会改变日志；需要一致列表时优先一次读完。
- 无效参数返回 `{ "ok": false, "error": { "code": "invalid_arguments", "message": "..." } }`。
- 玩家姓名受客户端机密值限制而不可访问时，省略 `character.name`。

## 新增：玩家上下文

```json
{"addon":"YYQQuestAPI","name":"get_player_context","args":{}}
```

返回原生 `character`（姓名、服务器、阵营、等级）、`experience`（current、maximum、rested、可选fraction）、`location`。位置包含 `available`、`coordinateMapID`、地图名和0..1的x/y，可能有 `world={continentID,x,y}`。无可用位置时提供reason，不填入虚构坐标；不会读取玩家生命或能量。

## 新增：原生任务 POI

```json
{"addon":"YYQQuestAPI","name":"get_quest_pois","args":{"questID":881}}
```

参数 mapID、questID 均可选，必须为正整数。mapID必须是当前客户端地图。offset默认0，limit默认50、最大100。

- 指定mapID：只查询该图。
- 不指定mapID：扫描艾泽拉斯947的后代地图，结果带mapScope说明扫描数量和范围；此范围不覆盖全部副本。
- 只返回当前日志任务。questID不在日志时返回空结果和 `reason="quest_not_in_log"`。
- 先按任务过滤、合并投影、稳定排序，再分页。total为过滤去重后的总数；rawCount为合并前记录数；无可用原始坐标的数量为unusableCount。
- 去重只合并同任务、同标记语义、同continentID且世界坐标距离不大于0.1的点。先选原图记录为固定代表，避免链式近邻误合并。无世界坐标时，仅合并坐标系和坐标完全相同的记录。

POI字段：questID、coordinateMapID、reportedMapID、x、y、units="normalized"、precision="quest_poi"、source="C_QuestLog.GetQuestsOnMap"、projectionCount、queryMapIDs、worldAvailable，以及可选world。世界坐标转换失败会保留地图坐标并给worldUnavailableReason。

**x/y属于coordinateMapID，reportedMapID不是它们的替代坐标系。**显示常见地图坐标时乘100。不同continentID的世界坐标不可直接比较；直线距离不是可行走路线。

POI的inProgress不能判断任务完成，numObjectives也不是实际完成进度。坐标会随游戏状态变化，应重新读取，不把一次查询结果永久缓存成刷新点数据库。

## 新增：任务详情（原生优先）

```json
{"addon":"YYQQuestAPI","name":"get_quest_details","args":{"questID":881}}
```

只要官方数据：

```json
{"addon":"YYQQuestAPI","name":"get_quest_details","args":{"questID":881,"allowDatabase":false}}
```

参数：questID必填；allowDatabase默认true；includePOIs默认true；offset/limit仅对数据库references分页，默认0/50、最大100。

返回 `policy="client_first"`、`official`、`database` 两部分：

- official：source="client"，available/inLog，当前日志任务quest，及可选pois、poiCoverage、poiRawCount。不在日志的任务明确available=false，不生成假的当前进度。
- database：source="QuestieDB"、版本和契约、数据库元数据、chain、references分页，以及特殊目标关系。没有数据库、版本不兼容、任务未收录、关闭补充或数据库读取报错时给available=false和reason，官方部分继续返回。
- references只返回接取、交付和目标的实体关系，不递归展开全部坐标。role为quest_start、quest_turn_in或objective_reference，kind为npc/object/item，id为实体ID。
- objective_reference的databaseGroup/databaseIndex是数据库位置，不是官方objectiveIndex；objectiveIndexMapping固定为not_inferred。生物关联不一定是击杀要求。
- chain只是数据库关系，不能据此判断后续任务当前可接。数据库的0值ID是缺省值，不能拿它继续查询。

## 新增：QuestieDB实体查询

```json
{"addon":"YYQQuestAPI","name":"get_database_entity","args":{"kind":"item","id":5100}}
```

```json
{"addon":"YYQQuestAPI","name":"get_database_entity","args":{"kind":"npc","id":3475}}
```

kind为npc、object或item，id为正整数；offset默认0，limit默认50、最大100。

- item返回直接掉落、容器或商人relations，按单条关系分页；不会递归展开容器，因此不会陷入循环关系。
- npc/object返回扁平locations，按单个位置记录分页，包括不能导航的记录。total是全部位置数，usableLocationTotal是有可用地图坐标的位置数；locationAvailability为available、missing或unusable。
- 坐标保留areaID、spawnIndex、originalX/originalY（0..100）、可选phase，同时统一提供0..1的x/y、coordinateMapID、地图名、可选world。phase仅保留原值，未验证玩家当前是否处于该相位；available只说明坐标可表达，不代表目标当前在场。
- (-1,-1)保留为available=false、reason=instance_only，不转换成导航坐标。缺失地图、显示抑制、无效坐标和客户端不支持的地图分别返回原因；合法(0,0)不会被当成未知。
- 支持映射表和本版本的数字赋值数据字符串，基础映射后应用override，不执行字符串，不自动进行Era→Forever二次换算。
- 数据库不存在时 `ok=true,available=false,reason=not_loaded`；实体不存在为entity_not_found；读取异常返回 `ok=false,error.code=database_error`。

其他Lua代码可使用 `WoWBridgeNS.YYQQuestAPI.GetPlayerContext/GetQuestPOIs/GetQuestDetails/GetDatabaseEntity`，参数与MCP入口一致。数据库在每次调用时动态发现，不需要新增游戏文件或修改toc。

## 简易地图升级路线

在原生 **M 地区地图**上显示编号和青色直线，橙色1号为下一步；右上角小地图同步显示附近路线。大地图关闭后小地图继续工作。不创建额外面板，不改变原生任务追踪或放弃任务。

- 默认排除副本/团队副本任务、精英任务、专业任务和手动跳过的任务。副本/精英以原生任务分类为准；专业优先看原生分类，缺失时用QuestieDB.requiredSkill补充。
- 只安排目标实际属于**玩家当前所在地图**的任务：用POI.reportedMapID判定目标归属，用coordinateMapID解释坐标。邻区任务即使能投影到当前地图内，也不纳入。当前地图由玩家位置决定，浏览其他地图不会切换规划范围。
- 以直线距离为基础，按客户端相对难度和已就绪的奖励经验校准权重，按 `直线距离 / 权重` 逐步选择。容易任务略优先、困难/极难及琐碎任务靠后，低收益主要顺路做/交；每个任务一次，不增加地形或交通评分，不按旧版等级阈值猜难度。
- 默认玩家相对上次规划位置移动100码后重排，每0.5秒检查；玩家跨地图或升级，即使位移不足100码也重排。任务进度更新在短暂合并事件后重排。
- 右键自己的编号标记跳过任务，立即重排；按服务器与角色保存跳过记录和移动阈值，正常退出/重载时由客户端写盘。
- 其他地图的任务保留在get_plan.excluded，reason=outside_current_map；缺少原生POI或无法换算坐标也给出原因，不用假点连线。
- 自有图层挂在地图canvas下，随缩放/平移变化；仅在查看玩家当前地区时显示，浏览其他地区隐藏。不会主动打开或切换暴雪地图。

命令：

| 命令 | 作用 |
| --- | --- |
| `/yyqroute` | 显示状态和命令提示 |
| `/yyqroute skip 852` | 跳过指定任务 |
| `/yyqroute unskip 852` | 恢复指定任务 |
| `/yyqroute unskip all` | 恢复全部手动跳过任务 |
| `/yyqroute distance 150` | 将移动重排阈值设为150码，范围10..5000 |
| `/yyqroute replan` | 解除本轮目标保持，按当前位置重新选择1号并归组 |
| `/yyqroute off`、`on` | 隐藏、显示路线 |

额外的WoWBridge入口，addon仍为YYQQuestAPI：

- `get_plan({})`：当前steps、excluded、origin、sequence、moveThreshold和policy。scope=current_player_map_active_quests，policy=stable_grouped_leveling_straight_line；mapID/mapName为玩家地区，levelPriority保留referenceLevel，perLevelBonus=0、maxWeight=1.25、method=client_difficulty_and_reward。levelingPriority提供经验参照、难度权重、低收益阈值、pendingRewardCount及rewardRetrySeconds。每步priority给难度/经验来源与可用性、因子及排序原因。每步含targetMapID、priorityWeight/weightedDistance和groupIndex/groupSize，segmentDistance仍是真实直线距离。新增groups（index/anchor/questIDs/count）、groupRadius=200、stability（retained/reason/previousQuestID/questID/可选lastProgressAt）。
- `replan({})`：主动重排，绕过当前目标保持和旧区域延续，以新1号重新归组。
- `set_quest_skip({questID:852,skipped:true})`：跳过；false恢复。
- `reset_quest_skips({})`：清空当前角色手动跳过。
- `set_route_options({moveThreshold:100,enabled:true})`：路线选项。

对应Lua函数为GetPlan、Replan、SetQuestSkip、ResetQuestSkips、SetRouteOptions。原生任务POI是参考点；路线按用户要求只表示直线，不做道路寻路。Shift+M区域图尚未在当前客户端验证。

### 适合升级的任务优先（r7）

客户端C_PlayerInfo.GetContentDifficultyQuestForPlayer返回的Trivial/Easy/Fair/Difficult/Impossible，在任务进行中分别给难度权重0.4/1.25/1/0.65/0.4；IsQuestTrivial=true也按琐碎处理。未知难度按1，完全缺失时回到距离排序。任务等级仅展示，不再每低一级累加权重。

经验使用本客户端已实测的GetQuestLogRewardXP(questID)，只在HaveQuestData和HaveQuestRewardData均为true时接受有限非负结果。函数缺失/读取失败、缓存未就绪或受限值标记未知，绝不当作0；缓存就绪的0经验因子为0.5。

本次已过滤、同图Easy/Fair候选至少3项已知正奖励时，用其中位数作相对参照：不足参照25%经验因子0.55，不足50%为0.8。另用UnitXPMax提供本级升级所需总经验：不足0.5%也给0.55，不足1%给0.8；两种参照取较低因子。参照未知不猜值，所有信息不足时经验因子1。比例是简单路线策略，不能解释为精确经验/小时或服务端衰减规则。

最终权重为难度×经验因子，仍按距离÷权重选择，最大1.25。已完成/待交的任务难度权重为1，经验因子最低0.85，便于附近交付；complete但未ready时priority.reason与action均为completion_pending，不宣称已可交付。

悬停现有地图编号可见建议与客户端奖励经验。任务/奖励加载事件会合并刷新；暂缺奖励每5秒复查，全就绪后停止，不要求玩家必须移动。难度高或奖励低只降权，不自动跳过任务。更完整的实测依据见工作区升级优先级调研.md。

### 目标稳定与附近任务归组

- 自动更新仍重读原生POI与任务状态，但候选只有在加权距离至少改善30%、同时至少减少50加权码时才替换旧1号，避免距离接近时来回跳换。
- 对仍在进行中的1号：距参考点120码内优先保持；或在300码内且最近90秒有真实目标计数增长时保持。这是工作区域保护，不代表到点就完成。
- 状态变为complete/ready_for_turn_in、任务被跳过/失败/移除、目标转到其他图、位置缺失，或POI移动超过100码时，解除旧目标保持。重新使用客户端当前坐标；complete但尚无ready标记时，action=completion_pending，提示确认交付信息。
- 原生目标数据暂缺/空表/读取异常时不伪造进度；计数重置、目标结构或顺序变化也不刷新90秒保护。时间戳只保存在本次UI会话内，不写进SavedVariables。
- 一个任务组以首个点为固定中心，先安排其200码内的任务，再选下一组。不会沿着相邻点不断扩大分组。组内仍用距离/适合升级的权重排序；同任务多点只选择符合本组距离的一处，每个任务只出现一次。
- 当前任务完成/消失/跳过后，玩家仍在原区域300码内时，优先接着安排原组剩余有效任务；不满足时重新选区。悬停编号显示“附近还有N个任务”和最多3个任务名。
- `/yyqroute replan`或API replan可随时主动重新选择，不受上述保持/旧组影响。热加载复用框体但重新绑定回调，确保两张地图提示同步更新。

### 右上角小地图

- 使用同一份当前地区路线，橙色1号为下一目标；后续点仅在附近显示。下一目标超出视野时，将1号放在边缘指示方向，提示文字明确它是视野外目标。
- 使用原生C_Minimap.GetViewRadius读取实时视野半径，配合世界坐标投影；缩放变化无需重新规划，旋转模式结合GetPlayerFacing和IsRotateMinimapIgnored更新方向。
- 线段按圆形边界裁剪，只画真实路线在视野内的部分，不把多个视野外点夹到边缘后重新连线。中心留出角色箭头位置。
- 绘制每0.1秒更新；位置采样与原有移动重排仍每0.5秒进行。附近点随移动更新，无需先走满100码。
- 小地图编号也可右键跳过。`/yyqroute off`、`on`和set_route_options.enabled同时控制大地图、小地图。
- 当前小地图为圆形；对其他外形保留内接椭圆范围。没有位置/视野半径或旋转朝向时隐藏本次图层，不保留错误方向。

## 验证与安装

2026-11-12 在客户端1.60.1.70888、Interface16001验证。热加载检查无错误、无警告。当前Lua5.1隔离检查共282项通过，覆盖原有数据/规划/小地图/目标稳定/归组，更新有意废弃的旧权重断言，并新增68项升级优先、经验缓存和原地刷新场景。

离线验证还实际重执行源码，覆盖同namespace复用、旧revision缺字段升级、新namespace启动；确认driver不重复、两张地图共用步骤、旧回调被替换、跳过记录继续有效、不跨UI会话恢复基于GetTime的工作保护。

最新在线快照：贫瘠之地9个可规划任务、7个区域组，正常参照7个样本、中位数1650。蝎卵权重0.65、野猪人的武器0.4；已完成奥格拉和镰爪龙的交付点同组，逃跑与矿工宝贝同组。查询经验未改变当前选中任务；load和try无错误/警告/拦截。任务与分组数量会随游戏进度变化。

离线测试位于工作区 `C:\Users\Pillar\Desktop\WowFac\tests\verify_quest_data.py`，使用lupa.lua51在独立环境运行，不连接游戏。

本次只改已有Lua和本文档，热加载已生效，无需再次重启。运行时修订以apiRevision=7为准；toc包版本仍为0.1.0，本次未改toc。修改前工坊checkpoint=20。完成版检查点与离线备份见工作区开发进度.md；第4项明确赶路/工作状态和第5项逐目标导航继续记录在待办事项.md。
