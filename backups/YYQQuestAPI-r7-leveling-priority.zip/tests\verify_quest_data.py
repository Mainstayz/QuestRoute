"""Offline Lua 5.1 checks of public quest-data contracts and failure isolation.

Needs lupa (tests use lupa.lua51). Example:
  python tests/verify_quest_data.py
This harness executes the installed addon against isolated, deterministic API fixtures.
It does not connect to or change the game.
"""
from pathlib import Path
import argparse
from lupa.lua51 import LuaRuntime

DEFAULT_ADDON = Path(r"C:\Program Files (x86)\World of Warcraft\_forever_\Interface\AddOns\YYQQuestAPI\YYQQuestAPI.lua")

SETUP = r'''
Fixture = {
    mapOrder = {101, 102, 103}, pois = {}, conversionFail = {},
    worldContinent = {}, worldOffset = {}, phase = 7,
    spawns = {[17] = {{0, 0}, {-1, -1}, {55, 20, 7}}, [718] = {{20, 20}}},
    metadataVersion = 'test-version',
}
local function clone(value)
    if type(value) ~= 'table' then return value end
    local out = {}; for k,v in pairs(value) do out[k] = clone(v) end; return out
end
function canaccessvalue(value) return true end
function UnitName() return 'FixturePlayer' end
function GetRealmName() return 'FixtureRealm' end
function UnitLevel() return 19 end
function UnitXP() return 100 end
function UnitXPMax() return 1000 end
function GetXPExhaustion() return 0 end
function UnitFactionGroup() return 'Horde' end
function CreateVector2D(x,y) return {x=x,y=y} end
function IsLoggedIn() return Fixture.loggedIn or false end
function GetTime() return Fixture.time or 0 end
function CreateFrame(kind,name,parent)
    local f={scripts={},events={},parent=parent}
    function f:GetFrameLevel() return self.level or 3 end
    function f:GetWidth() return self.width or 200 end
    function f:GetHeight() return self.height or 200 end
    function f:GetScale() return self.scale or 1 end
    function f:SetScale(scale) self.scale=scale end
    function f:IsShown() return self.shown~=false end
    function f:SetSize(w,h) self.width=w;self.height=h end
    function f:RegisterForClicks(button) self.click=button end
    function f:ClearAllPoints() self.point=nil end
    function f:SetPoint(...) self.point={...} end
    function f:SetColorTexture(...) self.color={...} end
    function f:SetTextColor(...) self.textColor={...} end
    function f:SetText(text) self.text=text end
    function f:SetThickness(value) self.thickness=value end
    function f:SetStartPoint(...) self.startPoint={...} end
    function f:SetEndPoint(...) self.endPoint={...} end
    function f:CreateTexture() return CreateFrame('Texture',nil,self) end
    function f:CreateFontString() return CreateFrame('FontString',nil,self) end
    function f:CreateLine() return CreateFrame('Line',nil,self) end
    function f:IsVisible() return self.shown~=false and (not self.parent or not self.parent.IsVisible or self.parent:IsVisible()) end
    function f:RegisterEvent(event) self.events[event]=true end
    function f:UnregisterAllEvents() self.events={} end
    function f:SetScript(event,func) self.scripts[event]=func end
    function f:GetScript(event) return self.scripts[event] end
    function f:SetAllPoints(parent) self.parent=parent end
    function f:SetFrameLevel(level) self.level=level end
    function f:EnableMouse(enabled) self.mouse=enabled end
    function f:Show() self.shown=true end
    function f:Hide() self.shown=false end
    return f
end
SlashCmdList = {}
C_PlayerInfo={GetContentDifficultyQuestForPlayer=function(id)
    local value=Fixture.difficulties and Fixture.difficulties[id]
    if value==false then return nil end
    return value or 2
end}
function HaveQuestData(id) return not (Fixture.uncached and Fixture.uncached[id]) end
function HaveQuestRewardData(id) return not (Fixture.rewardMissing and Fixture.rewardMissing[id]) end
function GetQuestLogRewardXP(id)
    assert(type(id)=='number' and id>0,'reward reads require explicit questID')
    local value=Fixture.rewards and Fixture.rewards[id]
    if value==false then return nil end
    return value or 1000
end
C_AddOns = {GetAddOnMetadata=function() return Fixture.metadataVersion end}
C_Map = {
    GetMapInfo = function(id) if id == 279 or id == 9999 then return nil end; return {mapID=id,name='Map '..id} end,
    GetBestMapForUnit = function() return Fixture.playerMapID or 101 end,
    GetPlayerMapPosition = function() return {x=Fixture.playerX or 0,y=Fixture.playerY or 0} end,
    GetMapChildrenInfo = function()
        local out = {}; for _,id in ipairs(Fixture.mapOrder) do out[#out+1] = {mapID=id} end; return out
    end,
    GetWorldPosFromMapPos = function(id,p)
        if Fixture.conversionFail[id] == 'throw' then error('fixture conversion error') end
        if Fixture.conversionFail[id] then return nil end
        return Fixture.worldContinent[id] or 1, {x=p.x*(Fixture.worldScale or 1)+(Fixture.worldOffset[id] or 0),y=p.y*(Fixture.worldScale or 1)}
    end,
}
C_QuestLog = {
    GetNumQuestLogEntries = function() return 2,2 end,
    GetInfo = function(i)
        return {questID=i,title='Official '..i,questLogIndex=i,level=19,isHeader=false}
    end,
    IsComplete = function(id) return id==2 end,
    IsFailed = function() return false end,
    ReadyForTurnIn = function(id) return id==2 end,
    GetQuestTagInfo = function(id) if id==1 then return {tagID=81,tagName='Dungeon'} end end,
    GetQuestObjectives = function() return {{text='Official skill goal',finished=false,numFulfilled=1,numRequired=1,type='object'}} end,
    GetQuestsOnMap = function(id) return clone(Fixture.pois[id] or {}) end,
    IsQuestTrivial = function(id) return Fixture.trivial and Fixture.trivial[id] or false end,
}
local mapStrings = {
    areaIdToUiMapId='return {\n [17] = 9999,\n [718] = 279,\n}',
    areaIdToUiMapIdOverride='return {\n [17] = 101,\n}',
}
local function entity(kind)
    return {
        Exists = function(id) return id ~= 999 end,
        name = function(id) return kind..id end,
        spawns = function() return clone(Fixture.spawns) end,
        npcDrops = function() return {1,2} end,
        objectDrops = function() return {3} end,
        itemDrops = function() return {4} end,
        vendors = function() return {5} end,
        startQuest = function() return 0 end,
    }
end
local quest = {
    Exists = function(id) return id ~= 999 end,
    name = function() return 'Conflicting database title' end,
    questLevel = function() return 2 end, requiredLevel = function() return 1 end,
    objectivesText = function() return {'Database trainer relation'} end,
    objectives = function() return {[1]={{5938,nil,3}}} end,
    startedBy = function() return {[1]={265810},[2]={3972},[3]={1234}} end,
    finishedBy = function() return {[2]={24776}} end,
    preQuestSingle = function() return {3} end, preQuestGroup = function() return {} end,
    childQuests = function() return {4} end, nextQuestInChain = function() return 4 end,
    exclusiveTo = function() return {} end,
}
FixtureDB = {
    addonName='QuestieDB',contractVersion=4,
    RequireContract=function() return true end,
    Quest=quest,Npc=entity('npc'),Object=entity('object'),Item=entity('item'),
    Support={Get=function() return {private=mapStrings} end},
    GetProvenance=function() return 'FixtureOwner' end,
}
LibQuestieDB=FixtureDB
function NewPOI(map,x,questID)
    return {questID=questID or 1,mapID=map,x=x,y=0,numObjectives=1,inProgress=true,isQuestStart=false}
end
'''

CHECKS = r'''
local api=WoWBridgeNS.YYQQuestAPI
local passed=0
local function check(value,label)
    if not value then error('FAIL: '..label) end
    passed=passed+1
end
local function points()
    local r=api.GetQuestPOIs({limit=100}); check(r.ok,'POI request succeeds'); return r
end
-- Projection order and canonical representative must not depend on child-map enumeration.
Fixture.pois={[101]={NewPOI(103,.01)},[102]={NewPOI(103,.012)},[103]={NewPOI(103,.011)}}
local r=points()
check(r.total==1 and r.pois[1].coordinateMapID==103 and r.pois[1].projectionCount==3,'native-map representative')
Fixture.mapOrder={103,101,102}; local reverse=points()
check(reverse.total==r.total and reverse.pois[1].x==r.pois[1].x,'map traversal order independent')
-- Fixed representative prevents A-B-C proximity chains from collapsing distant A/C.
Fixture.mapOrder={101,102,103}
Fixture.pois={[101]={NewPOI(101,0)},[102]={NewPOI(102,.09)},[103]={NewPOI(103,.18)}}
r=points(); check(r.total==2,'no transitive proximity collapse')
-- Threshold, separate world spaces, physically distinct points.
Fixture.pois={[101]={NewPOI(101,0)},[102]={NewPOI(101,.1)}}
r=points(); check(r.total==1,'distance 0.1 included')
Fixture.pois[102][1].x=.10001
r=points(); check(r.total==2,'distance greater than 0.1 excluded')
Fixture.pois[102][1].x=0; Fixture.worldContinent[102]=2
r=points(); check(r.total==2,'different continents preserved')
Fixture.worldContinent={}
-- A failed conversion retains the projected map frame instead of fabricating world coords.
Fixture.conversionFail={[102]=true}
r=points(); check(r.total==2,'nil world conversion preserves record')
local failed
for _,p in ipairs(r.pois) do if p.coordinateMapID==102 then failed=p end end
check(failed and not failed.worldAvailable and failed.worldUnavailableReason=='conversion_unavailable','world conversion reason')
Fixture.conversionFail[102]='throw'
r=points(); check(r.total==2,'throwing world conversion isolated')
Fixture.conversionFail={}
-- Semantic flags and real locations must survive deduplication.
Fixture.pois={[101]={NewPOI(101,0),NewPOI(101,.5)}}
Fixture.pois[101][2].isQuestStart=true
r=points(); check(r.total==2,'different semantic points retained')
-- Pagination happens after filtering and deduplication, on flat records.
Fixture.pois={[101]={NewPOI(101,0),NewPOI(101,.5),NewPOI(101,0,2)}}
r=points()
for i=0,r.total-1 do
    local page=api.GetQuestPOIs({offset=i,limit=1})
    check(page.total==r.total and page.pois[1].questID==r.pois[i+1].questID and page.pois[1].x==r.pois[i+1].x,'stable POI pages')
end
check(api.GetQuestPOIs({offset=1000}).count==0,'out-of-range empty POI page')
check(api.GetQuestPOIs({questID=999}).total==0,'not-in-log filter')
-- A secret-like failure is not fabricated into a coordinate; zero itself remains valid.
local context=api.GetPlayerContext({})
check(context.location.available and context.location.x==0,'zero coordinate valid')
-- DB coordinate units, overrides, phase, sentinel, nonexistent maps, flat pagination.
local entity=api.GetDatabaseEntity({kind='npc',id=1,limit=1})
check(entity.total==4 and entity.count==1 and entity.hasMore,'flat location pagination')
check(entity.locations[1].coordinateMapID==101 and entity.locations[1].available and entity.locations[1].x==0,'override and zero coordinate')
local sentinel=api.GetDatabaseEntity({kind='npc',id=1,offset=1,limit=1}).locations[1]
check(not sentinel.available and sentinel.reason=='instance_only' and sentinel.x==nil,'sentinel not navigable')
local phased=api.GetDatabaseEntity({kind='npc',id=1,offset=2,limit=1}).locations[1]
check(phased.phase==7 and phased.x==.55 and phased.originalX==55,'phase and coordinate units retained')
local invalidMap=api.GetDatabaseEntity({kind='npc',id=1,offset=3,limit=1}).locations[1]
check(not invalidMap.available and invalidMap.reason=='unsupported_map','unsupported map retained')
check(api.GetDatabaseEntity({kind='npc',id=999}).reason=='entity_not_found','unknown entity')
Fixture.spawns={}
check(api.GetDatabaseEntity({kind='npc',id=1}).locationAvailability=='missing','known entity missing coordinates')
Fixture.spawns={[17]={{1,2}}}
-- 1,001 points are paged; details do not recursively embed their geometry.
Fixture.spawns[17]={}; for i=1,1001 do Fixture.spawns[17][i]={i/20,25} end
entity=api.GetDatabaseEntity({kind='npc',id=1,limit=100})
check(entity.total==1001 and entity.count==100 and entity.nextOffset==100,'large location set bounded')
local details=api.GetQuestDetails({questID=1,limit=1})
check(details.database.count==1 and details.database.hasMore and details.database.locations==nil,'details paginate references without locations')
check(details.official.quest.title=='Official 1' and details.official.quest.objectives[1].text=='Official skill goal','official data wins')
check(details.database.objectiveIndexMapping=='not_inferred','no invented objective order')
check(details.official.quest.tag.id==81 and details.official.quest.tag.name=='Dungeon','native dungeon tag retained')
local full=api.GetQuestDetails({questID=1,limit=100})
local hasItemStart,hasObjectEnd=false,false
for _,ref in ipairs(full.database.references) do
    if ref.role=='quest_start' and ref.kind=='item' then hasItemStart=true end
    if ref.role=='quest_turn_in' and ref.kind=='object' and ref.id==24776 then hasObjectEnd=true end
end
check(hasItemStart and hasObjectEnd,'starter/finisher entity kinds retained')
local pending=api.GetQuestDetails({questID=2})
check(pending.official.quest.status=='ready_for_turn_in','native turn-in status wins over inProgress')
check(not api.GetQuestDetails({questID=999}).official.available,'unknown quest not fabricated')
local item=api.GetDatabaseEntity({kind='item',id=1,limit=2})
check(item.total==5 and item.count==2 and item.hasMore,'direct item relations paginated')
-- No DB at addon load/call time, incompatible contract, getter error, late load.
local db=LibQuestieDB
LibQuestieDB=nil
check(api.GetQuestDetails({questID=1}).official.available,'DB absence preserves native details')
check(api.GetDatabaseEntity({kind='npc',id=1}).reason=='not_loaded','DB absence explicit')
check(api.GetQuests({}).ok and api.GetQuestPOIs({}).ok,'native reads independent of DB')
LibQuestieDB=db
check(api.GetDatabaseEntity({kind='npc',id=1}).available,'late DB detected')
local contract=db.RequireContract
 db.RequireContract=function() return false end
check(api.GetDatabaseEntity({kind='npc',id=1}).reason=='unsupported_contract','contract mismatch explicit')
db.RequireContract=contract
local name=db.Quest.name; db.Quest.name=function() error('fixture DB read failure') end
local broken=api.GetQuestDetails({questID=1})
check(broken.ok and broken.official.available and broken.database.reason=='database_error','DB getter error isolated')
db.Quest.name=name
local spawns=db.Npc.spawns;db.Npc.spawns=function() error('fixture entity failure') end
check(api.GetDatabaseEntity({kind='npc',id=1}).error.code=='database_error','entity read error explicit')
db.Npc.spawns=spawns
local disabled=api.GetQuestDetails({questID=1,allowDatabase=false})
check(disabled.database.reason=='disabled_by_request' and disabled.official.available,'DB disabled per request')
-- Existing API contract and input validation.
local old=api.GetQuests({includeObjectives=false})
check(old.schemaVersion==1 and old.limit==100 and old.quests[1].objectives==nil,'old get_quests compatibility')
local cases={
    {api.GetQuestPOIs,{limit=0}},{api.GetQuestPOIs,{limit=101}},{api.GetQuestPOIs,{offset=-1}},
    {api.GetQuestPOIs,{mapID='101'}},{api.GetQuestPOIs,{mapID=9999}},
    {api.GetQuestPOIs,{limit=0/0}},{api.GetQuestPOIs,{offset=math.huge}},
    {api.GetQuestDetails,{questID=0}},{api.GetQuestDetails,{questID=1,allowDatabase='false'}},
    {api.GetDatabaseEntity,{kind='unknown',id=1}},{api.GetDatabaseEntity,{kind='npc',id=1.5}},
}
for _,c in ipairs(cases) do
    local value=c[1](c[2]);check(not value.ok and value.error.code=='invalid_arguments','invalid arguments')
end
-- Route contracts: only straight distance, mandatory filters, skip state, displacement threshold.
Fixture.worldScale=1000
Fixture.mapOrder={101,102,103}
Fixture.pois={[101]={}}
for id=101,107 do Fixture.pois[101][#Fixture.pois[101]+1]=NewPOI(101,(id-100)/10,id) end
C_QuestLog.GetNumQuestLogEntries=function() return 7,7 end
C_QuestLog.GetInfo=function(i) return {questID=100+i,title='Route '..(100+i),level=40,questLogIndex=i} end
C_QuestLog.GetQuestTagInfo=function(id) if id==104 then return {tagID=81,tagName='Dungeon'} end end
C_QuestLog.GetQuestType=function(id) return id==104 and 81 or 0 end
C_QuestLog.IsEliteQuest=function(id) return id==105 end
C_QuestLog.IsFailed=function(id) return id==107 end
C_QuestLog.IsComplete=function(id) return id==102 end
C_QuestLog.ReadyForTurnIn=function(id) return id==102 end
FixtureDB.Quest.requiredSkill=function(id) if id==106 then return {356,1} end end
local plan=api.Replan({})
check(plan.count==3,'instance elite profession and failed excluded')
check(plan.steps[1].questID==101 and plan.steps[2].questID==102 and plan.steps[3].questID==103,'nearest neighbor order')
check(plan.steps[1].level==40,'no unsolicited quest level filter')
check(plan.steps[2].action=='turn_in','turn-in action preserved')
local why={};for _,q in ipairs(plan.excluded) do why[q.questID]=q.reason end
check(why[104]=='instance' and why[105]=='elite' and why[106]=='profession','filter reasons')
api.SetQuestSkip({questID=102})
plan=api.GetPlan({})
check(plan.count==2 and plan.steps[1].questID==101 and plan.steps[2].questID==103,'skip removes entire quest')
check(YYQQuestAPIDB.routes['FixtureRealm:FixturePlayer'].skipped[102],'skip saved per character')
api.SetQuestSkip({questID=102,skipped=false})
check(api.GetPlan({}).count==3,'restore skipped quest')
-- Tick without the map: movement below threshold does not trigger replanning.
Fixture.loggedIn=true
Fixture.time=100
api.StartRoute()
local driver=api.route.driver
local tick=driver:GetScript('OnUpdate')
local sequence=api.GetPlan({}).sequence
Fixture.playerX=.05;Fixture.time=101;tick(driver,.5)
check(api.GetPlan({}).sequence==sequence,'50 unit displacement below 100 threshold')
Fixture.playerX=.1;Fixture.time=102;tick(driver,.5)
check(api.GetPlan({}).sequence==sequence+1 and api.GetPlan({}).reason=='player_moved','100 unit displacement replans')
sequence=api.GetPlan({}).sequence
Fixture.playerX=.15;Fixture.time=103;tick(driver,.5)
check(api.GetPlan({}).sequence==sequence,'threshold measured from last plan origin')
Fixture.playerX=.21;Fixture.time=104;tick(driver,.5)
check(api.GetPlan({}).sequence==sequence+1,'cumulative displacement from plan triggers')
sequence=api.GetPlan({}).sequence
local onEvent=driver:GetScript('OnEvent')
onEvent(driver,'QUEST_LOG_UPDATE')
Fixture.time=104.2;tick(driver,.5)
check(api.GetPlan({}).sequence==sequence,'quest events debounced')
Fixture.time=104.7;tick(driver,.5)
check(api.GetPlan({}).sequence==sequence+1,'quest progress triggers replan')
api.SetRouteOptions({moveThreshold=200})
check(api.GetPlan({}).moveThreshold==200,'movement threshold adjustable')
check(not api.SetRouteOptions({moveThreshold=0}).ok,'invalid threshold rejected')
api.SetRouteOptions({enabled=false})
check(not api.GetPlan({}).enabled,'display off stored')
api.SetRouteOptions({enabled=true,moveThreshold=100})
api.SetQuestSkip({questID=101});api.ResetQuestSkips({})
check(api.GetPlan({}).count==3,'all skips reset')
-- Lifecycle reuses driver and clears polling before reload.
api.OnUnload()
check(driver:GetScript('OnUpdate')==nil and next(driver.events)==nil,'unload stops driver')
api.OnReload()
check(api.route.driver==driver and driver:GetScript('OnUpdate')~=nil,'reload reuses driver')
local started=api.GetPlan({}).sequence
api.StartRoute()
check(api.GetPlan({}).sequence==started,'initialization idempotent')
-- Regression: a foreign target can project inside the current map (including extremely nearby points).
Fixture.playerX=0;Fixture.playerMapID=101;Fixture.time=200
C_QuestLog.GetNumQuestLogEntries=function() return 10,10 end
Fixture.questLevels={}
C_QuestLog.GetInfo=function(i)
    local id=100+i
    return {questID=id,title='Route '..id,level=Fixture.questLevels[id] or 40,questLogIndex=i}
end
Fixture.pois[101][#Fixture.pois[101]+1]=NewPOI(102,.00001,108)
Fixture.pois[101][#Fixture.pois[101]+1]=NewPOI(103,.00002,109)
Fixture.pois[101][#Fixture.pois[101]+1]=NewPOI(102,.00003,110)
Fixture.pois[101][#Fixture.pois[101]+1]=NewPOI(101,.9,110)
plan=api.Replan({})
check(plan.count==4 and plan.mapID==101 and plan.scope=='current_player_map_active_quests','current player map only')
why={};for _,q in ipairs(plan.excluded) do why[q.questID]=q.reason end
check(why[108]=='outside_current_map' and why[109]=='outside_current_map','near foreign projections excluded')
local multi
for _,q in ipairs(plan.steps) do
    check(q.targetMapID==101,'every selected target owned by player map')
    if q.questID==110 then multi=q end
end
check(multi and multi.x==.9,'multi-location quest uses local point not nearer foreign point')
-- r7 replaces level-gap bonuses: native difficulty wins; labels/unknown levels do not imply good XP.
Fixture.questLevels={[101]=19,[102]=16,[103]=14,[110]=19}
Fixture.pois[101][2].x=.15
Fixture.pois[101][3].x=.4
Fixture.difficulties={[103]=0};Fixture.trivial={[103]=true};Fixture.rewards={[103]=100}
plan=api.Replan({})
check(plan.steps[1].questID==101,'farther old low-level quest no longer wins only by level gap')
check(math.abs(plan.steps[1].weightedDistance-plan.steps[1].segmentDistance/plan.steps[1].priorityWeight)<.0001,'score still physical distance divided by weight')
local measured={};for _,q in ipairs(plan.steps) do measured[q.questID]=q end
check(measured[103].priorityWeight<1,'native trivial task is deprioritized')
Fixture.questLevels[103]=1
plan=api.Replan({})
for _,q in ipairs(plan.steps) do if q.questID==103 then check(q.priorityWeight<1,'very low levels do not regain old double bonus') end end
Fixture.questLevels[102]=19
plan=api.Replan({})
check(plan.steps[1].questID==101,'fair difficulty keeps nearby task first')
Fixture.difficulties={};Fixture.trivial={};Fixture.rewards={}
Fixture.questLevels[103]=0
plan=api.Replan({})
for _,q in ipairs(plan.steps) do if q.questID==103 then check(q.priorityWeight==1,'unknown level zero does not invent difficulty') end end
Fixture.questLevels[103]=-1
plan=api.Replan({})
for _,q in ipairs(plan.steps) do if q.questID==103 then check(q.priorityWeight==1,'dynamic level sentinel relies on native difficulty') end end
Fixture.questLevels[103]=40;Fixture.questLevels[102]=14;Fixture.pois[101][2].x=.5
plan=api.Replan({})
check(plan.steps[1].questID==101,'far low-level does not override much closer task')
Fixture.questLevels[101]=40
local unitLevel=UnitLevel;UnitLevel=function() return nil end
plan=api.Replan({})
check(plan.levelPriority.referenceLevel==nil,'unknown player level supported')
for _,q in ipairs(plan.steps) do check(q.priorityWeight==1,'fair native difficulty works without player level') end
UnitLevel=unitLevel;api.Replan({})
-- Cross a map boundary with zero world displacement: immediately replace local route.
Fixture.playerMapID=102;Fixture.time=201
local activeTick=driver:GetScript('OnUpdate')
activeTick(driver,.5)
plan=api.GetPlan({})
check(plan.mapID==102 and plan.reason=='player_map_changed','map change replans below movement threshold')
check(plan.count==2,'new map activates only its two targets')
for _,q in ipairs(plan.steps) do check(q.targetMapID==102,'new map target ownership') end
Fixture.playerMapID=101;Fixture.time=202;activeTick(driver,.5)
check(api.GetPlan({}).mapID==101 and api.GetPlan({}).count==4,'returning map restores its local candidates')
-- Browsing a different map never changes planning scope and hides the old region overlay.
local canvas={GetFrameLevel=function() return 3 end,GetWidth=function() return 1002 end,GetHeight=function() return 668 end}
WorldMapFrame={GetCanvas=function() return canvas end,GetMapID=function() return 102 end,IsShown=function() return true end}
sequence=api.GetPlan({}).sequence
Fixture.time=203;activeTick(driver,.5)
check(api.GetPlan({}).mapID==101 and api.GetPlan({}).sequence==sequence,'viewed map does not change player scope')
check(api.route.views[1].overlay.shown==false,'viewing other region hides local route overlay')
WorldMapFrame=nil
-- Level changes refresh weights even when standing still.
UnitLevel=function() return 20 end
Fixture.time=204;activeTick(driver,.5)
check(api.GetPlan({}).reason=='player_level_changed' and api.GetPlan({}).levelPriority.referenceLevel==20,'level-up recalculates weights')
UnitLevel=unitLevel
-- Minimap integration: known cardinal points, actual radius, rotation, geometry clipping, lifecycle.
Fixture.playerX=.5;Fixture.playerY=.5;Fixture.playerMapID=101
Fixture.radius=100;Fixture.rotate=false;Fixture.ignoreRotation=false;Fixture.facing=0
C_Minimap={GetViewRadius=function() return Fixture.radius end,IsRotateMinimapIgnored=function() return Fixture.ignoreRotation end}
C_CVar={GetCVarBool=function() return Fixture.rotate end}
function GetPlayerFacing() return Fixture.facing end
Minimap=CreateFrame('Minimap');Minimap:SetSize(200,200);Minimap:Show()
C_QuestLog.GetNumQuestLogEntries=function() return 3,3 end
C_QuestLog.GetInfo=function(i) return {questID=100+i,title='Mini '..i,level=19,questLogIndex=i} end
C_QuestLog.IsFailed=function() return false end
C_QuestLog.IsEliteQuest=function() return false end
C_QuestLog.GetQuestType=function() return 0 end
Fixture.pois={[101]={NewPOI(101,.55,101),NewPOI(101,.8,102),NewPOI(101,.9,103)}}
for _,p in ipairs(Fixture.pois[101]) do p.y=.5 end
plan=api.Replan({})
local function miniTick() Fixture.time=Fixture.time+1;activeTick(driver,.2) end
local function near(a,b) return math.abs(a-b)<.00001 end
miniTick()
local mini=api.route.minimapView
check(mini and mini.overlay:IsVisible() and WorldMapFrame==nil,'minimap renders while world map closed')
local pin=mini.pins[1]
check(near(pin.point[4],0) and near(pin.point[5],50),'north target 50 yards at radius100 is halfway up')
check(pin.step.questID==101 and not pin.onEdge,'nearby first target numbered at actual point')
check(not mini.pins[2] or not mini.pins[2]:IsVisible(),'far future target not clamped into fake point')
check(mini.lines[1]:IsVisible() and mini.lines[2]:IsVisible(),'nearby route segment and boundary continuation visible')
check(not mini.lines[3] or not mini.lines[3]:IsVisible(),'wholly outside segment hidden')
Fixture.radius=200;miniTick()
check(near(pin.point[5],25),'view radius change updates without replan')
Fixture.radius=100;Fixture.rotate=true;Fixture.facing=math.pi/2;miniTick()
check(near(pin.point[4],50) and near(pin.point[5],0),'west-facing rotation puts north on right')
Fixture.ignoreRotation=true;miniTick()
check(near(pin.point[4],0) and near(pin.point[5],50),'ignored rotation keeps north-up')
Fixture.ignoreRotation=false;Fixture.rotate=false
-- Next objective outside viewport: only its marker at rim; actual leg clipped at round border.
plan=api.GetPlan({})
plan.steps[1].world={continentID=1,x=800,y=500}
plan.steps[2].world={continentID=1,x=900,y=900}
miniTick()
check(pin.onEdge and near(pin.point[4],0) and near(pin.point[5],84),'offscreen next objective direction at inner rim')
check(near(mini.lines[1].endPoint[4],90) and near(mini.lines[1].startPoint[4],7),'line clipped to circle with gap for player arrow')
check(not mini.lines[2]:IsVisible(),'no phantom connection between clamped edge pins')
-- Outside-to-outside segment passing through the circle must retain its actual chord.
plan.steps[1].world={continentID=1,x=500,y=800}
plan.steps[2].world={continentID=1,x=500,y=200}
miniTick()
local chord=mini.lines[2]
check(chord:IsVisible() and near(chord.startPoint[3],-90) and near(chord.endPoint[3],90),'circle-crossing outside endpoints clipped to diameter')
-- Moving across the point updates its direction, without waiting 100 yards to replan.
plan.steps[1].world={continentID=1,x=550,y=500}
Fixture.playerX=.56;miniTick()
check(not pin.onEdge and pin.point[5]<0,'subthreshold movement updates target projection')
-- Independent map masks/size and display state do not create unbounded geometry.
Minimap:SetSize(240,120);miniTick()
for _,line in pairs(mini.lines) do
    if line:IsVisible() then
        for _,point in ipairs({line.startPoint,line.endPoint}) do
            check((point[3]/120)^2+(point[4]/60)^2<=.9^2+.00001,'all endpoints inside minimap ellipse')
        end
    end
end
local wasEnabled=plan.enabled;plan.enabled=false;miniTick()
check(not mini.overlay:IsVisible(),'route off hides minimap')
plan.enabled=wasEnabled;Minimap:Hide();miniTick()
check(not mini.overlay:IsVisible(),'hidden minimap hides overlay')
Minimap:Show();Fixture.radius=0;miniTick()
check(not mini.overlay:IsVisible(),'invalid view radius hides geometry')
Fixture.radius=100;Fixture.rotate=true;Fixture.facing=nil;miniTick()
check(not mini.overlay:IsVisible(),'missing facing under rotation hides stale direction')
Fixture.rotate=false;Fixture.facing=0;miniTick()
local cached=api.route.minimapView
api.OnUnload()
check(not cached.overlay:IsVisible() and pin.step==nil,'hot unload hides minimap and clears target references')
api.OnReload()
check(api.route.minimapView==cached and cached.overlay:IsVisible(),'hot reload reuses minimap overlay')
-- Reuse the same right-click interaction on small-map pins; restore the fixture afterward.
local pinID=mini.pins[1].step.questID
GameTooltip={Hide=function() end}
mini.pins[1]:GetScript('OnClick')(mini.pins[1],'RightButton')
check(YYQQuestAPIDB.routes['FixtureRealm:FixturePlayer'].skipped[pinID],'minimap right click uses quest skip')
api.SetQuestSkip({questID=pinID,skipped=false})
-- Intelligent route scenarios use independent quest rows; they never touch the live game.
Minimap=nil;WorldMapFrame=nil
Fixture.worldScale=1000;Fixture.playerMapID=101;Fixture.playerY=0;Fixture.time=1000
FixtureDB.Quest.requiredSkill=function() return nil end
local function routeRow(id,x,extra)
    local row=extra or {};row.id=id;row.x=x;return row
end
local function rowFor(id) for _,row in ipairs(Fixture.routeRows) do if row.id==id then return row end end end
C_QuestLog.GetNumQuestLogEntries=function() return #Fixture.routeRows,#Fixture.routeRows end
C_QuestLog.GetInfo=function(i)
    local row=Fixture.routeRows[i]
    return {questID=row.id,title='Stable '..row.id,level=row.level or 19,questLogIndex=i}
end
C_QuestLog.GetQuestTagInfo=function() return nil end
C_QuestLog.IsComplete=function(id) local row=rowFor(id);return row and (row.complete or row.ready) or false end
C_QuestLog.ReadyForTurnIn=function(id) local row=rowFor(id);return row and row.ready or false end
C_QuestLog.IsFailed=function(id) local row=rowFor(id);return row and row.failed or false end
C_PlayerInfo.GetContentDifficultyQuestForPlayer=function(id)
    local row=rowFor(id);if row.difficulty==false then return nil end
    return row.difficulty or 2
end
C_QuestLog.IsQuestTrivial=function(id) local row=rowFor(id);return row.trivial or false end
function HaveQuestData(id) return not rowFor(id).uncached end
function HaveQuestRewardData(id) return not rowFor(id).rewardMissing end
function GetQuestLogRewardXP(id)
    assert(type(id)=='number' and rowFor(id),'explicit active questID required')
    local row=rowFor(id);if row.xp==false then return nil end
    return row.xp or 1000
end
C_QuestLog.GetQuestObjectives=function(id)
    local row=rowFor(id)
    if row.missing then return nil end
    if row.empty then return {} end
    if row.readError then error('temporary objective cache failure') end
    if row.objectives then return row.objectives end
    return {{type=row.kind or 'monster',text='Goal '..id..': '..(row.fulfilled or 0)..'/'..(row.required or 10),
        numFulfilled=row.fulfilled or 0,numRequired=row.required or 10,finished=row.finished or false}}
end
local function syncPOIs()
    Fixture.pois={[101]={}}
    for _,row in ipairs(Fixture.routeRows) do
        if not row.noPOI then
            local poi=NewPOI(row.map or 101,row.x/Fixture.worldScale,row.id);poi.y=(row.y or 0)/Fixture.worldScale
            Fixture.pois[101][#Fixture.pois[101]+1]=poi
            for _,x in ipairs(row.otherX or {}) do Fixture.pois[101][#Fixture.pois[101]+1]=NewPOI(row.map or 101,x/Fixture.worldScale,row.id) end
        end
    end
end
local function scenario(rows,playerX)
    Fixture.routeRows=rows;Fixture.playerX=(playerX or 0)/Fixture.worldScale;Fixture.playerY=0
    Fixture.playerMapID=101;Fixture.time=Fixture.time+10
    api.route.plan=nil;api.route.progress={};YYQQuestAPIDB.routes['FixtureRealm:FixturePlayer'].skipped={}
    syncPOIs();return api.Replan({})
end
local function autoPlan()
    syncPOIs()
    local d=api.route.driver
    d:GetScript('OnEvent')(d,'QUEST_LOG_UPDATE')
    Fixture.time=Fixture.time+1
    d:GetScript('OnUpdate')(d,.2)
    return api.GetPlan({})
end
-- The incumbent is a little worse after walking: keep it, but honor manual replan.
local rows={routeRow(201,500),routeRow(202,900)}
plan=scenario(rows)
check(plan.steps[1].questID==201,'stability baseline picks weighted nearest')
Fixture.playerX=.73;plan=autoPlan()
check(plan.steps[1].questID==201 and plan.stability.reason=='avoid_small_switch','small improvement does not reverse direction')
plan=api.Replan({})
check(plan.steps[1].questID==202 and plan.stability.reason=='manual_replan','manual replan immediately bypasses hold')
-- Clearly better (>30% and >=50 weighted yards), then repeated updates stay on chosen target.
scenario({routeRow(201,500),routeRow(202,900)})
Fixture.playerX=.76;plan=autoPlan()
check(plan.steps[1].questID==202 and plan.stability.reason=='clearly_better_candidate','large improvement switches target')
local target=plan.steps[1].questID
for i=1,3 do plan=autoPlan() end
check(plan.steps[1].questID==target,'repeated quest events do not bounce target')
-- A ratio improvement alone on short distances must not trigger a pointless switch.
scenario({routeRow(201,200,{ready=true}),routeRow(202,300,{ready=true})})
Fixture.playerX=.26;plan=autoPlan()
check(plan.steps[1].questID==201,'ratio threshold alone cannot override minimum saving')
-- When actually at the objective, strong alternatives do not pull player away.
rows={routeRow(201,500),routeRow(202,900)}
scenario(rows);rows[2].x=610;Fixture.playerX=.6;plan=autoPlan()
check(plan.steps[1].questID==201 and plan.stability.reason=='at_objective_area','working at objective retains first even against much closer alternative')
check(plan.steps[1].status=='in_progress' and not rowFor(201).complete,'arrival never fabricates quest completion')
-- Recent actual progress extends work area to300 yards; loading objectives does not count.
rows={routeRow(201,500),routeRow(202,900)}
scenario(rows);rows[1].fulfilled=1;rows[2].x=750;Fixture.playerX=.76
plan=autoPlan()
check(plan.steps[1].questID==201 and plan.stability.reason=='recent_objective_progress','count increase holds ongoing task within work area')
local progressAt=api.route.progress[201].lastProgressAt
rows[1].missing=true;plan=autoPlan()
check(api.route.progress[201].lastProgressAt==progressAt,'temporarily missing objectives preserve real progress timestamp')
rows[1].missing=false;rows[1].empty=true;plan=autoPlan()
check(api.route.progress[201].lastProgressAt==progressAt,'empty target cache is not treated as completed or reset')
rows[1].empty=false;Fixture.time=Fixture.time+91;plan=autoPlan()
check(plan.steps[1].questID==202,'expired progress protection releases when other task clearly better')
rows={routeRow(201,500,{missing=true}),routeRow(202,900)}
scenario(rows);rows[1].missing=false;rows[1].fulfilled=5;rows[2].x=750;Fixture.playerX=.76
plan=autoPlan()
check(plan.steps[1].questID==202 and not api.route.progress[201].lastProgressAt,'first objective data load is not fabricated progress')
-- A nearby old point moving to a new target area must not remain a locked destination.
rows={routeRow(201,400),routeRow(202,900)}
scenario(rows);rows[1].x=950;rows[2].x=410;Fixture.playerX=.4;plan=autoPlan()
check(plan.steps[1].questID==202 and not plan.stability.retained,'large POI change releases old target')
rows={routeRow(201,400),routeRow(202,900)}
scenario(rows);rows[1].fulfilled=1;rows[2].x=750;Fixture.playerX=.76;plan=autoPlan()
check(plan.steps[1].questID==202,'progress outside300yard work area does not trap route')
-- Readiness/completion, filtering, missing targets, and skips override previous working lock.
rows={routeRow(201,500),routeRow(202,900)}
scenario(rows);rows[1].ready=true;rows[1].x=950;rows[2].x=610;Fixture.playerX=.6
plan=autoPlan()
check(plan.steps[1].questID==202,'completion and new turnin location release former objective')
local turnin;for _,s in ipairs(plan.steps) do if s.questID==201 then turnin=s end end
check(turnin and turnin.action=='turn_in' and turnin.world.x==950,'completed task now routes to refreshed native turnin point')
rows={routeRow(201,500),routeRow(202,900)}
scenario(rows);rows[1].failed=true;Fixture.playerX=.5;plan=autoPlan()
check(plan.steps[1].questID==202,'failed incumbent excluded despite proximity')
rows={routeRow(201,500),routeRow(202,900)}
scenario(rows);rows[1].map=102;Fixture.playerX=.5;plan=autoPlan()
check(plan.steps[1].questID==202,'target leaving current map releases working lock')
rows={routeRow(201,500),routeRow(202,900)}
scenario(rows);rows[1].noPOI=true;plan=autoPlan()
check(plan.steps[1].questID==202,'target coordinate disappearance never keeps stale destination')
rows={routeRow(201,500),routeRow(202,900)}
scenario(rows);table.remove(rows,1);plan=autoPlan()
check(plan.steps[1].questID==202 and api.route.progress[201]==nil,'removed quest pruned from route and progress cache')
scenario({routeRow(201,500),routeRow(202,900)});Fixture.playerX=.5;autoPlan()
api.SetQuestSkip({questID=201});plan=api.GetPlan({})
check(plan.steps[1].questID==202,'skip overrides incumbent working area')
-- Release working hold even when only IsComplete is available, not ReadyForTurnIn yet.
rows={routeRow(201,500),routeRow(202,900)}
scenario(rows);rows[1].complete=true;rows[1].x=950;rows[2].x=610;Fixture.playerX=.6;plan=autoPlan()
check(plan.steps[1].questID==202,'IsComplete alone releases active working lock')
for _,s in ipairs(plan.steps) do if s.questID==201 then check(s.action=='completion_pending','completed without ready flag never advertised as doing objectives') end end
-- Exact hysteresis boundaries use weighted distances, not incorrectly unscaled squares.
for _,case in ipairs({{200,160,false},{200,140,true},{150,105,false},{150,100,true}}) do
    rows={routeRow(201,case[1],{ready=true}),routeRow(202,900,{ready=true})}
    scenario(rows);rows[2].x=case[2];plan=autoPlan()
    check((plan.steps[1].questID==202)==case[3],'ratio and minimum-saving threshold boundary')
end
for _,distance in ipairs({120,120.01}) do
    rows={routeRow(201,distance),routeRow(202,900)}
    scenario(rows);rows[2].x=10;plan=autoPlan()
    check((plan.steps[1].questID==201)==(distance==120),'arrival radius equality and just outside')
end
for _,shift in ipairs({100,100.01}) do
    rows={routeRow(201,500),routeRow(202,900)}
    scenario(rows);rows[1].x=500+shift;rows[2].x=551;Fixture.playerX=.55;plan=autoPlan()
    check((plan.steps[1].questID==201)==(shift==100),'POI movement tolerance equality and just outside')
end
rows={routeRow(201,500),routeRow(202,900)}
scenario(rows);rows[1].fulfilled=1;rows[2].x=210;Fixture.playerX=.2;plan=autoPlan()
check(plan.steps[1].questID==201,'recent work300yard equality retains target')
Fixture.time=Fixture.time+89;plan=autoPlan()
check(plan.steps[1].questID==201 and plan.stability.reason=='recent_objective_progress','recent work90second equality retains target')
Fixture.time=Fixture.time+.01;plan=autoPlan()
check(plan.steps[1].questID==202,'recent progress protection expires after90seconds')
-- Counts resetting, rearranged targets and another quest progress cannot create protection.
rows={routeRow(201,500,{fulfilled=3}),routeRow(202,900)}
scenario(rows);rows[1].fulfilled=2;rows[2].x=750;rows[2].fulfilled=1;Fixture.playerX=.76;plan=autoPlan()
check(plan.steps[1].questID==202 and not api.route.progress[201].lastProgressAt,'regression and other quest progress do not count for incumbent')
rows={routeRow(201,500),routeRow(202,900)}
rows[1].objectives={{type='monster',text='Wolf: 3/10',numFulfilled=3,numRequired=10,finished=false},
    {type='monster',text='Boar: 0/10',numFulfilled=0,numRequired=10,finished=false}}
scenario(rows)
rows[1].objectives={rows[1].objectives[2],rows[1].objectives[1]}
rows[2].x=750;Fixture.playerX=.76;plan=autoPlan()
check(plan.steps[1].questID==202 and not api.route.progress[201].lastProgressAt,'reordered objectives are baseline changes not progress')
rows={routeRow(201,500),routeRow(202,900)}
scenario(rows);rows[1].fulfilled=1;rows[2].x=750;Fixture.playerX=.76;autoPlan()
progressAt=api.route.progress[201].lastProgressAt
rows[1].readError=true;plan=autoPlan()
check(plan.ok and api.route.progress[201].lastProgressAt==progressAt,'throwing objective read isolated and snapshot preserved')
rows[1].readError=false;plan=autoPlan()
check(api.route.progress[201].lastProgressAt==progressAt,'same counters after cache recovery do not refresh time')
-- Alternative locations for the same task remain distinct destinations, and grouping selects a real local point.
rows={routeRow(201,500,{otherX={900}}),routeRow(202,700)}
scenario(rows);Fixture.playerX=.89;plan=autoPlan()
check(plan.steps[1].questID==201 and plan.steps[1].world.x==900,'same quest can switch to clearly nearer alternative POI')
rows={routeRow(201,500),routeRow(202,300,{otherX={900}}),routeRow(203,880)}
plan=scenario(rows,500)
check(plan.steps[2].questID==202 and plan.steps[2].world.x==300,'group chooses only qualifying location of multi-POI quest')
-- Fixed-anchor grouping: a B-C bridge must not bypass another task still in A's area.
plan=scenario({routeRow(201,500),routeRow(202,690),routeRow(203,880),routeRow(204,305)},500)
check(plan.steps[1].questID==201 and plan.steps[2].questID==202 and plan.steps[3].questID==204 and plan.steps[4].questID==203,'complete A-B-D-C order prevents transitive bridge')
check(#plan.groups==2 and plan.steps[1].groupSize==3 and plan.steps[4].groupSize==1,'group membership is fixed to original area anchor')
local seen={}
for _,s in ipairs(plan.steps) do
    check(not seen[s.questID],'grouped route does not duplicate quests');seen[s.questID]=true
    local anchor=plan.groups[s.groupIndex].anchor
    check((s.world.x-anchor.x)^2+(s.world.y-anchor.y)^2<=200^2+.00001,'all group members remain within original200yard anchor')
end
plan=scenario({routeRow(201,500),routeRow(202,700),routeRow(203,700.01)},500)
check(plan.steps[2].groupIndex==1 and plan.steps[3].groupIndex==2,'200yard group boundary included and farther point starts new group')
plan=scenario({routeRow(201,200),routeRow(202,390),routeRow(203,700,{level=14,difficulty=1}),routeRow(204,5)},200)
check(plan.steps[3].questID==204 and plan.steps[4].questID==203,'nearby ordinary task precedes leaving area for lower-level task')
-- Finish nearby group after completing first task, but manual replan bypasses group continuity.
rows={routeRow(201,500),routeRow(202,680),routeRow(203,710,{level=14,difficulty=1})}
plan=scenario(rows,500);check(plan.groups[1].count==2,'local group baseline')
table.remove(rows,1);Fixture.playerX=.52;plan=autoPlan()
check(plan.steps[1].questID==202 and plan.stability.reason=='continue_nearby_group','completed incumbent continues remaining local task')
check(plan.groups[1].anchor.x==500,'group anchor does not drift across replans')
plan=api.Replan({})
check(plan.steps[1].questID==203 and plan.groups[1].anchor.x==710,'manual replan resets old target and old area preference')
plan=autoPlan();check(plan.steps[1].questID==203,'ordinary event after manual choice never resurrects old hold')
-- API and slash both release a target protected by proximity and real objective progress.
rows={routeRow(201,500),routeRow(202,900)}
scenario(rows);rows[1].fulfilled=1;rows[2].x=610;Fixture.playerX=.6;plan=autoPlan()
check(plan.steps[1].questID==201,'protected target before slash replan')
SlashCmdList['YYQROUTE']('replan');plan=api.GetPlan({})
check(plan.steps[1].questID==202 and plan.stability.reason=='manual_replan','slash replan bypasses proximity and progress protection')
-- Read-only POIs changing to no available location should yield an empty route, not stale1.
for _,row in ipairs(rows) do row.noPOI=true end
plan=autoPlan();check(plan.count==0 and plan.stability.questID==nil,'no candidates cleanly clears first and groups')
-- r7 leveling scenarios exercise real route choices with native difficulty and cached rewards.
Fixture.worldScale=10000
local function stepFor(id)
    for _,s in ipairs(api.GetPlan({}).steps) do if s.questID==id then return s end end
end
rows={routeRow(201,600),routeRow(202,650,{difficulty=1,level=16}),
    routeRow(203,550,{difficulty=0,trivial=true,level=1,xp=100}),
    routeRow(204,700,{difficulty=3,xp=1300}),routeRow(205,750,{difficulty=4,xp=2000}),routeRow(206,2000)}
plan=scenario(rows)
check(plan.steps[1].questID==202,'easy normal-reward task can beat slightly nearer fair task')
check(stepFor(203).priorityWeight<stepFor(201).priorityWeight,'very low-level trivial task no longer gets maximum bonus')
check(stepFor(204).priorityWeight<stepFor(201).priorityWeight and stepFor(205).priorityWeight<stepFor(204).priorityWeight,'difficult and impossible quests progressively deferred')
check(plan.count==6,'priority adjustments do not filter or abandon high-level or low-reward tasks')
check(plan.levelingPriority.reference.sampleCount==3 and plan.levelingPriority.reference.value==1000,'reference uses eligible positive easy-fair native rewards')
check(plan.levelPriority.perLevelBonus==0,'obsolete level-gap bonus explicitly disabled')
rows={routeRow(201,600,{difficulty=1,level=60}),routeRow(202,620,{difficulty=3,level=1})}
plan=scenario(rows)
check(plan.steps[1].questID==201,'native difficulty takes precedence over misleading quest-level labels')
rows={routeRow(201,600),routeRow(202,650,{difficulty=4,xp=100000})}
plan=scenario(rows)
check(plan.steps[1].questID==201,'large raw XP never cancels extreme combat difficulty')
-- Low XP lowers priority for ongoing objectives; completed tasks need no additional combat.
rows={routeRow(201,600),routeRow(202,550,{difficulty=1,xp=100}),routeRow(203,2000),routeRow(204,2100)}
plan=scenario(rows)
check(plan.steps[1].questID==201,'easy but very low-reward task yields to nearby normal-reward task')
check(stepFor(202).priority.reason=='low_reward_on_the_way','low-reward reason is observable in API')
rows[2].ready=true;plan=api.Replan({})
check(plan.steps[1].questID==201 and stepFor(202).priorityWeight<1,'low-reward turnin remains a moderate on-the-way preference')
rows[2].x=300;syncPOIs();plan=api.Replan({})
check(plan.steps[1].questID==202 and plan.steps[1].action=='turn_in','nearby low-reward turnin can still be recommended')
rows={routeRow(201,600),routeRow(202,550,{difficulty=4,xp=1000,ready=true}),routeRow(203,2000)}
plan=scenario(rows)
check(plan.steps[1].questID==202 and stepFor(202).priority.difficultyWeight==1,'already-completed high-level task has no combat penalty')
rows[2].ready=false;rows[2].complete=true;plan=api.Replan({})
check(plan.steps[1].questID==202 and plan.steps[1].action=='completion_pending','complete-without-ready also releases combat difficulty penalty')
-- Reward caches are distinct: missing/invalid data is not a verified zero reward.
rows={routeRow(201,500,{xp=0}),routeRow(202,550,{xp=0,rewardMissing=true}),routeRow(203,2000),routeRow(204,2100),routeRow(205,2200)}
plan=scenario(rows)
check(plan.steps[1].questID==202,'unknown reward stays neutral while verified zero is deweighted')
check(stepFor(201).priority.experience.available and stepFor(201).priority.experience.value==0,'cached zero reward is explicitly represented')
check(not stepFor(202).priority.experience.available and stepFor(202).priority.experience.value==nil,'uncached zero is unavailable rather than zero experience')
check(stepFor(202).priority.experienceWeight==1,'unknown XP never receives low-reward penalty')
local beforeLoad=plan.sequence
rows[2].rewardMissing=false
local dataDriver=api.route.driver
syncPOIs();dataDriver:GetScript('OnEvent')(dataDriver,'QUEST_DATA_LOAD_RESULT',202,true)
Fixture.time=Fixture.time+1;dataDriver:GetScript('OnUpdate')(dataDriver,.2);plan=api.GetPlan({})
check(plan.sequence==beforeLoad+1 and plan.reason=='QUEST_DATA_LOAD_RESULT','active quest data-load event refreshes priority without walking')
check(stepFor(202).priority.experience.available and stepFor(202).priority.experienceWeight<1,'newly ready reward participates in ranking')
local previousSequence=plan.sequence
dataDriver:GetScript('OnEvent')(dataDriver,'QUEST_DATA_LOAD_RESULT',99999999,true)
Fixture.time=Fixture.time+1;dataDriver:GetScript('OnUpdate')(dataDriver,.2)
check(api.GetPlan({}).sequence==previousSequence,'unrelated cache event does not rebuild current route')
-- Reward/difficulty reader failures and missing APIs are isolated from the route.
local xpReader=GetQuestLogRewardXP
GetQuestLogRewardXP=function() error('fixture reward read failure') end
plan=api.Replan({})
check(plan.ok and plan.count==5 and not stepFor(201).priority.experience.available,'reward read errors preserve all route candidates')
check(stepFor(201).priority.experience.reason=='read_error' and stepFor(201).priority.experienceWeight==1,'failed reward reads explicitly neutral')
GetQuestLogRewardXP=nil;plan=api.Replan({})
check(stepFor(201).priority.experience.reason=='api_unavailable','missing undocumented XP API falls back cleanly')
GetQuestLogRewardXP=xpReader
local rewardCache=HaveQuestRewardData
HaveQuestRewardData=nil;plan=api.Replan({})
check(not stepFor(201).priority.experience.available and stepFor(201).priorityWeight==1,'no reward-cache API never assumes zero XP is ready')
HaveQuestRewardData=rewardCache
rows[1].uncached=true;rows[1].difficulty=0;rows[1].trivial=true
plan=api.Replan({})
check(not stepFor(201).priority.difficulty.available and not stepFor(201).priority.experience.available and stepFor(201).priorityWeight==1,'quest data not ready does not create trivial or zero-XP penalty')
rows[1].uncached=false;rows[1].trivial=false
for _,bad in ipairs({-1,math.huge,0/0,false}) do
    rows[1].xp=bad;plan=api.Replan({})
    check(not stepFor(201).priority.experience.available,'invalid native reward excluded without inventing zero')
end
rows[1].xp=1000;rows[1].difficulty=false;plan=api.Replan({})
check(stepFor(201).priority.difficulty.name=='unknown' and stepFor(201).priorityWeight==1,'unknown difficulty uses neutral fallback')
rows[1].difficulty=99;plan=api.Replan({})
check(stepFor(201).priorityWeight==1,'unknown future enum value never crashes or gets fabricated bonus')
local difficultyReader=C_PlayerInfo.GetContentDifficultyQuestForPlayer
C_PlayerInfo.GetContentDifficultyQuestForPlayer=function() error('fixture difficulty read failure') end
plan=api.Replan({})
check(plan.ok and not stepFor(201).priority.difficulty.available,'difficulty read error isolated')
C_PlayerInfo.GetContentDifficultyQuestForPlayer=difficultyReader
rows[1].difficulty=2;rows[1].trivial=true;plan=api.Replan({})
check(stepFor(201).priority.difficulty.code==0 and stepFor(201).priorityWeight<1,'native trivial flag overrides neutral enum fallback')
local oldAccessible=canaccessvalue
canaccessvalue=function(value) return value~='secret-fixture' end
GetQuestLogRewardXP=function(id) if id==201 then return 'secret-fixture' end return xpReader(id) end
rows[1].trivial=false;rows[1].difficulty='secret-fixture';plan=api.Replan({})
check(not stepFor(201).priority.experience.available and stepFor(201).priority.experience.reason=='restricted','restricted reward never enters arithmetic')
check(not stepFor(201).priority.difficulty.available and stepFor(201).priority.difficulty.reason=='restricted','restricted difficulty never used as table key')
canaccessvalue=oldAccessible;GetQuestLogRewardXP=xpReader
-- Reward thresholds and small-sample fallback use current filtered candidates only.
for _,case in ipairs({{249,true},{250,false},{499,false},{500,false}}) do
    rows={routeRow(201,600,{xp=case[1]}),routeRow(202,1200),routeRow(203,1800),routeRow(204,2400),routeRow(205,3000)}
    plan=scenario(rows)
    check(stepFor(201).priority.lowReward==case[2],'25percent low-reward classification boundary')
    check((stepFor(201).priority.experienceWeight<1)==(case[1]<500),'50percent discount boundary')
end
plan=scenario({routeRow(201,600,{xp=10}),routeRow(202,900,{xp=1000})})
check(not plan.levelingPriority.reference.available and stepFor(201).priority.experienceWeight==1,'fewer than3 samples never claim precise low-reward baseline')
rows={routeRow(201,600,{xp=1000}),routeRow(202,1200,{xp=1100}),routeRow(203,1800,{xp=1200}),routeRow(204,2400,{xp=1000000})}
plan=scenario(rows)
check(plan.levelingPriority.reference.value==1150,'median resists extreme reward outlier')
local originalType,originalElite,originalTag=C_QuestLog.GetQuestType,C_QuestLog.IsEliteQuest,C_QuestLog.GetQuestTagInfo
C_QuestLog.GetQuestType=function(id) return rowFor(id).instance and 81 or 0 end
C_QuestLog.IsEliteQuest=function(id) return rowFor(id).elite or false end
C_QuestLog.GetQuestTagInfo=function(id) if rowFor(id).profession then return {tradeskillLineID=356} end end
rows={routeRow(201,600),routeRow(202,1200),routeRow(203,1800),routeRow(204,1900,{map=102,xp=1000000}),
    routeRow(205,2000,{instance=true,xp=1000000}),routeRow(206,2100,{elite=true,xp=1000000}),
    routeRow(207,2200,{profession=true,xp=1000000}),routeRow(208,2300,{xp=1000000})}
scenario(rows);api.SetQuestSkip({questID=208});plan=api.GetPlan({})
check(plan.count==3 and plan.levelingPriority.reference.sampleCount==3 and plan.levelingPriority.reference.value==1000,'foreign instance elite profession and skipped quests cannot contaminate reference')
local exclusions={};for _,e in ipairs(plan.excluded) do exclusions[e.questID]=e.reason end
check(exclusions[204]=='outside_current_map' and exclusions[205]=='instance' and exclusions[206]=='elite' and exclusions[207]=='profession' and exclusions[208]=='skipped','all mandatory filters survive priority integration')
C_QuestLog.GetQuestType,C_QuestLog.IsEliteQuest,C_QuestLog.GetQuestTagInfo=originalType,originalElite,originalTag
-- Small rewards cannot normalize each other when the next-level experience requirement is known.
local xpMaximum=UnitXPMax
UnitXPMax=function() return 20000 end
rows={routeRow(201,600,{xp=1000}),routeRow(202,550,{difficulty=1,xp=10}),routeRow(203,650,{difficulty=1,xp=10})}
plan=scenario(rows)
check(plan.levelingPriority.reference.value==10 and plan.steps[1].questID==201,'tiny-reward majority cannot hide low progression value')
check(stepFor(202).priority.lowReward and stepFor(202).priority.experience.fractionOfLevel==.0005,'real per-level progress makes tiny rewards observable')
for _,case in ipairs({{99,true,true},{100,false,true},{199,false,true},{200,false,false}}) do
    plan=scenario({routeRow(201,600,{xp=case[1]}),routeRow(202,1200,{xp=1000})})
    check(stepFor(201).priority.lowReward==case[2],'half-percent per-level threshold boundary')
    check((stepFor(201).priority.experienceWeight<1)==case[3],'one-percent per-level threshold boundary')
end
UnitXPMax=function() return nil end
plan=scenario({routeRow(201,600,{xp=10}),routeRow(202,900)})
check(stepFor(201).priority.experienceWeight==1 and stepFor(201).priority.experience.fractionOfLevel==nil,'missing level XP requirement never invents progression fraction')
UnitXPMax=xpMaximum
-- An independently filled reward cache refreshes without any event or player movement.
rows={routeRow(201,450,{xp=0,rewardMissing=true}),routeRow(202,500)}
plan=scenario(rows)
check(plan.steps[1].questID==201 and plan.levelingPriority.pendingRewardCount==1,'unknown reward can start as nearest candidate with retry scheduled')
rows[1].rewardMissing=false;Fixture.time=plan.plannedAt+4.99
local cacheTick=api.route.driver:GetScript('OnUpdate')
cacheTick(api.route.driver,.2)
check(api.GetPlan({}).sequence==plan.sequence,'cache retry waits five seconds')
Fixture.time=plan.plannedAt+5;cacheTick(api.route.driver,.2);plan=api.GetPlan({})
check(plan.reason=='reward_cache_refresh' and plan.steps[1].questID==202,'independent cache completion changes priorities while standing still')
check(plan.levelingPriority.pendingRewardCount==0 and api.route.nextRewardCheck==nil,'fully loaded rewards stop retry polling')
previousSequence=plan.sequence;Fixture.time=Fixture.time+10;cacheTick(api.route.driver,.2)
check(api.GetPlan({}).sequence==previousSequence,'loaded data does not trigger recurring route rebuild')
rows={routeRow(201,100,{xp=0,rewardMissing=true}),routeRow(202,105)}
plan=scenario(rows);rows[1].rewardMissing=false;Fixture.time=plan.plannedAt+5;cacheTick(api.route.driver,.2)
plan=api.GetPlan({})
check(plan.steps[1].questID==201 and plan.stability.reason=='at_objective_area','cache refresh still respects task already being worked nearby')
plan=api.Replan({})
check(plan.steps[1].questID==202,'manual choice applies updated reward and bypasses work protection')
plan=scenario({routeRow(201,500,{complete=true}),routeRow(202,900)})
check(stepFor(201).action=='completion_pending' and stepFor(201).priority.reason=='completion_pending','pending completion never claims turnin availability in priority explanation')
-- Prepare real two-map frame pools for the Python harness to re-execute source on same namespace.
Fixture.worldScale=1000
scenario({routeRow(201,500),routeRow(202,680)},500)
Minimap=CreateFrame('Minimap');Minimap:Show();Fixture.radius=100;Fixture.rotate=false
local hotCanvas=CreateFrame('Frame');hotCanvas:SetSize(1002,668)
WorldMapFrame=CreateFrame('Frame');WorldMapFrame.GetCanvas=function() return hotCanvas end
WorldMapFrame.GetMapID=function() return 101 end;WorldMapFrame:Show()
C_Map.GetMapPosFromWorldPos=function(continent,point,mapID) return mapID,{x=point.x/1000,y=point.y/1000} end
Fixture.time=Fixture.time+1;activeTick(driver,.2)
FixtureHotload={driver=api.route.driver,mini=api.route.minimapView,world=api.route.views[#api.route.views]}
FixtureHotload.oldEnter=FixtureHotload.mini.pins[1]:GetScript('OnEnter')
return passed
'''


RELOAD_CHECKS = r'''
local api=WoWBridgeNS.YYQQuestAPI
local passed=0
local function check(value,label)
    if not value then error('FAIL: '..label) end
    passed=passed+1
end
local h=FixtureHotload
check(api.route.driver==h.driver and api.route.driver:GetScript('OnUpdate')~=nil,'source re-execution reuses one live driver')
check(api.route.minimapView==h.mini,'source re-execution reuses small-map pool')
check(api.route.views[#api.route.views]==h.world,'source re-execution reuses world-map pool')
check(h.mini.pins[1]:GetScript('OnEnter')~=h.oldEnter,'source re-execution replaces old tooltip closure')
check(h.mini.pins[1].step==h.world.pins[1].step,'both maps share same current step')
check(api.route.plan.groups[1].count==2,'source reload keeps grouped route valid')
GameTooltip={lines={},SetOwner=function() end,SetText=function(self,text) self.title=text end,
    AddLine=function(self,text) self.lines[#self.lines+1]=text end,Show=function() end,Hide=function() end}
h.mini.pins[1]:GetScript('OnEnter')(h.mini.pins[1])
local nearby,experienceTip=false,false
for _,line in ipairs(GameTooltip.lines) do
    if line:find('附近还有',1,true) then nearby=true end
    if line:find('客户端奖励经验',1,true) then experienceTip=true end
end
check(nearby,'reused map pin exposes updated group tooltip after source reload')
check(experienceTip,'reused pin shows new native reward explanation after source reload')
local sequence=api.route.plan.sequence
api.OnReload()
check(api.route.plan.sequence==sequence,'reload hook does not duplicate file-load initialization')
return passed
'''

LEGACY_RELOAD_CHECKS = r'''
local api=WoWBridgeNS.YYQQuestAPI
assert(api.apiRevision==7 and api.route.plan.stability,'legacy namespace gains new policy fields')
assert(api.route.progress and api.route.plan.groups,'legacy namespace without progress and groups upgrades')
assert(api.route.plan.steps[1].questID==202,'skipped legacy first never resurrected on source reload')
assert(api.route.driver==FixtureHotload.driver,'legacy upgrade still reuses driver')
return 4
'''

FRESH_RELOAD_CHECKS = r'''
local api=WoWBridgeNS.YYQQuestAPI
assert(api.route.driver~=FixtureHotload.driver,'new namespace creates own driver')
assert(FixtureHotload.driver:GetScript('OnUpdate')==nil and next(FixtureHotload.driver.events)==nil,'old driver is inactive after namespace replacement')
assert(api.route.plan.steps[1].questID==202,'fresh login preserves saved skip preferences')
assert(api.route.plan.stability.retained==false,'fresh session does not restore uptime-based target hold')
assert(api.route.minimapView.pins[1].step==api.route.views[1].pins[1].step,'fresh namespace maps share same steps')
return 5
'''


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--addon", type=Path, default=DEFAULT_ADDON)
    args = parser.parse_args()
    runtime = LuaRuntime(unpack_returned_tuples=True)
    runtime.execute(SETUP)
    source = args.addon.read_text(encoding="utf-8-sig")
    namespace = runtime.table()
    runtime.execute(source, "YYQQuestAPI", namespace)
    passed = runtime.execute(CHECKS)
    namespace.OnUnload()
    runtime.execute(source, "YYQQuestAPI", namespace)
    passed += runtime.execute(RELOAD_CHECKS)
    runtime.execute("""
        local api=WoWBridgeNS.YYQQuestAPI
        api.OnUnload()
        api.route.progress=nil;api.route.plan.groups=nil;api.route.plan.stability=nil
        for _,step in ipairs(api.route.plan.steps) do step.groupIndex=nil;step.groupSize=nil end
        YYQQuestAPIDB.routes['FixtureRealm:FixturePlayer'].skipped[201]=true
    """)
    runtime.execute(source, "YYQQuestAPI", namespace)
    passed += runtime.execute(LEGACY_RELOAD_CHECKS)
    namespace.OnUnload()
    runtime.execute(source, "YYQQuestAPI", runtime.table())
    passed += runtime.execute(FRESH_RELOAD_CHECKS)
    print(f"PASS: {passed} isolated Lua 5.1 checks; addon={args.addon}")


if __name__ == "__main__":
    main()
