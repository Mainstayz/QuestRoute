-- YYQ 角色任务 API：实时读取当前角色已接取的任务，不改变任务日志或追踪设置。
local addonName, ns = ...
WoWBridgeNS = WoWBridgeNS or {}
WoWBridgeNS[addonName] = ns

local WB = WoWBridge and WoWBridge.Bind and WoWBridge.Bind(addonName) or {
    Emit = function() end,
    Expose = function() end,
    Request = function(_, _, _, callback)
        callback(nil, "unavailable")
    end,
}
ns.WB = WB

local function InvalidArguments(message)
    return { ok = false, error = { code = "invalid_arguments", message = message } }
end

local function ReadQuest(info, category, includeObjectives)
    local questID = info.questID
    local isComplete = C_QuestLog.IsComplete(questID)
    local isFailed = C_QuestLog.IsFailed(questID)
    local readyForTurnIn = C_QuestLog.ReadyForTurnIn(questID)
    local status = "in_progress"
    if isFailed then
        status = "failed"
    elseif readyForTurnIn then
        status = "ready_for_turn_in"
    elseif isComplete then
        status = "complete"
    end

    local quest = {
        questID = questID,
        title = info.title,
        category = category,
        logIndex = info.questLogIndex,
        level = info.level,
        suggestedGroup = info.suggestedGroup,
        frequency = info.frequency,
        classification = info.questClassification,
        isHidden = info.isHidden,
        isTask = info.isTask,
        isStory = info.isStory,
        isComplete = isComplete,
        isFailed = isFailed,
        readyForTurnIn = readyForTurnIn,
        status = status,
    }

    local tag = C_QuestLog.GetQuestTagInfo(questID)
    if tag then
        quest.tag = { id = tag.tagID, name = tag.tagName, isElite = tag.isElite, tradeskillLineID = tag.tradeskillLineID }
    end

    if includeObjectives then
        local rawObjectives = C_QuestLog.GetQuestObjectives(questID)
        quest.objectivesLoaded = rawObjectives ~= nil
        quest.objectives = {}
        for index, objective in ipairs(rawObjectives or {}) do
            quest.objectives[index] = {
                index = index,
                text = objective.text,
                type = objective.type,
                objectiveType = objective.objectiveType,
                finished = objective.finished,
                numFulfilled = objective.numFulfilled,
                numRequired = objective.numRequired,
            }
        end
    end
    return quest
end

-- 供其他 Lua 代码调用：WoWBridgeNS.YYQQuestAPI.GetQuests({ ... })。
-- offset 为从 0 开始的偏移，limit 默认为 100；每次调用都重新读取角色当前日志。
function ns.GetQuests(args)
    if args == nil then args = {} end
    if type(args) ~= "table" then
        return InvalidArguments("args must be an object")
    end

    local offset = args.offset
    if offset == nil then offset = 0 end
    local limit = args.limit
    if limit == nil then limit = 100 end
    if type(offset) ~= "number" or offset < 0 or offset % 1 ~= 0 then
        return InvalidArguments("offset must be a non-negative integer")
    end
    if type(limit) ~= "number" or limit < 1 or limit > 100 or limit % 1 ~= 0 then
        return InvalidArguments("limit must be an integer from 1 to 100")
    end
    if args.includeObjectives ~= nil and type(args.includeObjectives) ~= "boolean" then
        return InvalidArguments("includeObjectives must be a boolean")
    end
    local includeObjectives = args.includeObjectives ~= false

    local numEntries, reportedTotal = C_QuestLog.GetNumQuestLogEntries()
    local all, category = {}, nil
    -- 本客户端的 GetInfo 可直接读取折叠分类下的任务，无需展开或修改用户界面。
    for logIndex = 1, numEntries do
        local info = C_QuestLog.GetInfo(logIndex)
        if info then
            if info.isHeader then
                category = info.title
            elseif info.questID and info.questID > 0 then
                all[#all + 1] = { info = info, category = category }
            end
        end
    end

    local quests = {}
    local lastIndex = math.min(#all, offset + limit)
    for index = offset + 1, lastIndex do
        local entry = all[index]
        quests[#quests + 1] = ReadQuest(entry.info, entry.category, includeObjectives)
    end

    local playerName = UnitName("player")
    if not canaccessvalue(playerName) then playerName = nil end
    local hasMore = offset + #quests < #all
    local result = {
        ok = true,
        schemaVersion = 1,
        scope = "active_quest_log",
        character = { name = playerName, realm = GetRealmName() },
        total = #all,
        reportedTotal = reportedTotal,
        logComplete = #all == reportedTotal,
        offset = offset,
        limit = limit,
        count = #quests,
        hasMore = hasMore,
        quests = quests,
    }
    if hasMore then result.nextOffset = offset + #quests end
    return result
end

WB:Expose("get_quests", ns.GetQuests,
    "只读获取当前角色所有已接取任务（含折叠分类、隐藏任务和已完成待交任务）。"
    .. "args: offset>=0（默认0），limit=1..100（默认100），includeObjectives=true/false（默认true）。"
    .. "返回角色、total、reportedTotal、logComplete、count、hasMore、nextOffset 和 quests；"
    .. "每项含 questID/title/category/status 及 objectives 目标进度。"
    .. "不包含已交付任务历史或尚未接取任务。")

SLASH_YYQQUESTAPI1 = "/yyqquestapi"
SlashCmdList["YYQQUESTAPI"] = function()
    local result = ns.GetQuests({ includeObjectives = false })
    print("|cffd8a85aYYQQuestAPI|r 当前任务：" .. result.total)
    for _, quest in ipairs(result.quests) do
        print("[" .. quest.questID .. "] " .. quest.title .. " (" .. quest.status .. ")")
    end
end

-- 数据层修订 2：客户端原生数据优先，QuestieDB 仅提供独立标注的补充。
-- 动态发现数据库：不在文件加载时持有它，未安装或尚未加载也能使用原生接口。
ns.apiRevision = 7

local function IsFinite(value)
    return canaccessvalue(value) and type(value) == "number"
        and value == value and value > -math.huge and value < math.huge
end

local function IsID(value)
    return IsFinite(value) and value > 0 and value % 1 == 0
end

local function Accessible(value)
    if canaccessvalue(value) then return value end
end

local function ParsePage(args)
    local offset = args.offset
    local limit = args.limit
    if offset == nil then offset = 0 end
    if limit == nil then limit = 50 end
    if not IsFinite(offset) or offset < 0 or offset % 1 ~= 0 then
        return nil, "offset must be a non-negative integer"
    end
    if not IsID(limit) or limit > 100 then
        return nil, "limit must be an integer from 1 to 100"
    end
    return { offset = offset, limit = limit }
end

local function AddPage(result, all, page, field)
    local out = {}
    for i = page.offset + 1, math.min(#all, page.offset + page.limit) do
        out[#out + 1] = all[i]
    end
    result.total = #all
    result.offset = page.offset
    result.limit = page.limit
    result.count = #out
    result.hasMore = page.offset + #out < #all
    if result.hasMore then result.nextOffset = page.offset + #out end
    result[field] = out
    return result
end

local function ActiveQuestIndex()
    local byID, category = {}, nil
    local numEntries = C_QuestLog.GetNumQuestLogEntries()
    for i = 1, numEntries do
        local info = C_QuestLog.GetInfo(i)
        if info then
            if info.isHeader then
                category = info.title
            elseif IsID(info.questID) then
                byID[info.questID] = { info = info, category = category }
            end
        end
    end
    return byID
end

local function ToWorld(mapID, x, y)
    if not IsID(mapID) or not IsFinite(x) or not IsFinite(y) then return nil end
    local ok, continentID, position = pcall(C_Map.GetWorldPosFromMapPos, mapID, CreateVector2D(x, y))
    if ok and position and IsFinite(continentID) and IsFinite(position.x) and IsFinite(position.y) then
        return { continentID = continentID, x = position.x, y = position.y }
    end
end

function ns.GetPlayerContext(args)
    if args ~= nil and type(args) ~= "table" then return InvalidArguments("args must be an object") end
    local mapID = Accessible(C_Map.GetBestMapForUnit("player"))
    local mapInfo = IsID(mapID) and C_Map.GetMapInfo(mapID) or nil
    local position = mapInfo and C_Map.GetPlayerMapPosition(mapID, "player") or nil
    local x, y = position and Accessible(position.x), position and Accessible(position.y)
    local hasPosition = IsFinite(x) and IsFinite(y) and x >= 0 and x <= 1 and y >= 0 and y <= 1
    local xp, maxXP = Accessible(UnitXP("player")), Accessible(UnitXPMax("player"))
    local character = {
        name = Accessible(UnitName("player")), realm = GetRealmName(),
        level = Accessible(UnitLevel("player")), faction = Accessible(UnitFactionGroup("player")),
    }
    local result = {
        ok = true, schemaVersion = 1, apiRevision = ns.apiRevision, source = "client",
        character = character,
        experience = { current = xp, maximum = maxXP, rested = Accessible(GetXPExhaustion()) },
        location = {
            available = hasPosition, coordinateMapID = mapID, mapName = mapInfo and mapInfo.name,
            units = "normalized", source = "C_Map.GetPlayerMapPosition",
        },
    }
    if IsFinite(xp) and IsFinite(maxXP) and maxXP > 0 then result.experience.fraction = xp / maxXP end
    if hasPosition then
        result.location.x, result.location.y = x, y
        result.location.world = ToWorld(mapID, x, y)
    else
        result.location.reason = mapInfo and "position_unavailable" or "map_unavailable"
    end
    return result
end

-- 地图 POI 的 x/y 属于查询地图，不一定属于返回项的 mapID。
local function SamePOI(a, b)
    if a.questID ~= b.questID or a.isQuestStart ~= b.isQuestStart
        or a.isMeta ~= b.isMeta or a.isMapIndicatorQuest ~= b.isMapIndicatorQuest then return false end
    if a.world and b.world and a.world.continentID == b.world.continentID then
        local dx, dy = a.world.x - b.world.x, a.world.y - b.world.y
        return math.sqrt(dx * dx + dy * dy) <= 0.1
    end
    return a.coordinateMapID == b.coordinateMapID
        and a.reportedMapID == b.reportedMapID and a.x == b.x and a.y == b.y
end

local function CollectPOIs(args, active)
    local maps, seenMaps = {}, {}
    local scope = { kind = "single_map", mapID = args.mapID }
    if args.mapID then
        maps[1] = args.mapID
    else
        scope = { kind = "map_tree", rootMapID = 947, includesAllInstanceMaps = false }
        for _, info in ipairs(C_Map.GetMapChildrenInfo(947, nil, true) or {}) do
            if IsID(info.mapID) and not seenMaps[info.mapID] then
                maps[#maps + 1] = info.mapID
                seenMaps[info.mapID] = true
            end
        end
        table.sort(maps)
    end
    local raw, points, byQuest, rawCount, unusableCount = {}, {}, {}, 0, 0
    for _, queryMapID in ipairs(maps) do
        for _, poi in ipairs(C_QuestLog.GetQuestsOnMap(queryMapID) or {}) do
            if IsID(poi.questID) and active[poi.questID] and (not args.questID or poi.questID == args.questID) then
                rawCount = rawCount + 1
                if IsFinite(poi.x) and IsFinite(poi.y) and poi.x >= 0 and poi.x <= 1 and poi.y >= 0 and poi.y <= 1 then
                    local point = {
                        questID = poi.questID, coordinateMapID = queryMapID, reportedMapID = poi.mapID,
                        x = poi.x, y = poi.y, units = "normalized", precision = "quest_poi",
                        source = "C_QuestLog.GetQuestsOnMap", numObjectives = poi.numObjectives,
                        isQuestStart = poi.isQuestStart, inProgress = poi.inProgress,
                        isDaily = poi.isDaily, isMeta = poi.isMeta,
                        isCombatAllyQuest = poi.isCombatAllyQuest,
                        isMapIndicatorQuest = poi.isMapIndicatorQuest,
                        world = ToWorld(queryMapID, poi.x, poi.y),
                    }
                    point.worldAvailable = point.world ~= nil
                    if not point.worldAvailable then point.worldUnavailableReason = "conversion_unavailable" end
                    raw[#raw + 1] = point
                else
                    unusableCount = unusableCount + 1
                end
            end
        end
    end
    -- 先确定固定代表点，再去重；合并时不移动代表点，避免链式近邻误合并。
    table.sort(raw, function(a, b)
        if a.questID ~= b.questID then return a.questID < b.questID end
        local aNative, bNative = a.coordinateMapID == a.reportedMapID, b.coordinateMapID == b.reportedMapID
        if aNative ~= bNative then return aNative end
        if a.coordinateMapID ~= b.coordinateMapID then return a.coordinateMapID < b.coordinateMapID end
        if a.x ~= b.x then return a.x < b.x end
        return a.y < b.y
    end)
    for _, point in ipairs(raw) do
        local candidates = byQuest[point.questID] or {}
        local existing
        for _, candidate in ipairs(candidates) do
            if SamePOI(candidate, point) then existing = candidate; break end
        end
        if existing then
            existing.projectionCount = existing.projectionCount + 1
            existing.queryMapIDs[#existing.queryMapIDs + 1] = point.coordinateMapID
        else
            point.projectionCount, point.queryMapIDs = 1, { point.coordinateMapID }
            points[#points + 1] = point
            candidates[#candidates + 1] = point
            byQuest[point.questID] = candidates
        end
    end
    table.sort(points, function(a, b)
        if a.questID ~= b.questID then return a.questID < b.questID end
        if a.coordinateMapID ~= b.coordinateMapID then return a.coordinateMapID < b.coordinateMapID end
        if a.x ~= b.x then return a.x < b.x end
        return a.y < b.y
    end)
    scope.scannedMaps = #maps
    return points, { mapScope = scope, rawCount = rawCount, unusableCount = unusableCount }
end

function ns.GetQuestPOIs(args)
    if args == nil then args = {} end
    if type(args) ~= "table" then return InvalidArguments("args must be an object") end
    if args.mapID ~= nil and not IsID(args.mapID) then return InvalidArguments("mapID must be a positive integer") end
    if args.questID ~= nil and not IsID(args.questID) then return InvalidArguments("questID must be a positive integer") end
    local page, message = ParsePage(args)
    if not page then return InvalidArguments(message) end
    if args.mapID and not C_Map.GetMapInfo(args.mapID) then return InvalidArguments("mapID is not a client map") end
    local active = ActiveQuestIndex()
    local points, meta = CollectPOIs(args, active)
    local result = {
        ok = true, schemaVersion = 1, apiRevision = ns.apiRevision, source = "client",
        scope = "active_quest_log", mapScope = meta.mapScope,
        rawCount = meta.rawCount, unusableCount = meta.unusableCount,
    }
    if args.questID and not active[args.questID] then result.reason = "quest_not_in_log" end
    return AddPage(result, points, page, "pois")
end

local function GetDatabase()
    local db = rawget(_G, "LibQuestieDB")
    if type(db) ~= "table" then return nil, { available = false, source = "QuestieDB", reason = "not_loaded" } end
    if type(db.RequireContract) ~= "function" then
        return nil, { available = false, source = "QuestieDB", reason = "unsupported_contract" }
    end
    local called, compatible = pcall(db.RequireContract, 4)
    if not called or not compatible then
        return nil, { available = false, source = "QuestieDB", reason = "unsupported_contract" }
    end
    local name = type(db.addonName) == "string" and db.addonName or "QuestieDB"
    local metadataOK, version = pcall(C_AddOns.GetAddOnMetadata, name, "Version")
    return db, {
        available = true, source = "QuestieDB", contract = db.contractVersion,
        version = metadataOK and version or nil,
    }
end

local cachedDB, cachedBase, cachedOverride, cachedMapping
local function AreaMapping(db)
    local support = db.Support and db.Support.Get and db.Support.Get("ZoneDB")
    local private = support and support.private or {}
    local base, override = private.areaIdToUiMapId, private.areaIdToUiMapIdOverride
    if cachedDB == db and cachedBase == base and cachedOverride == override then return cachedMapping end
    local mapping = {}
    for _, value in ipairs({ base or false, override or false }) do
        if type(value) == "string" then
            -- 只接受数字赋值行，不执行数据库中的字符串。
            for line in value:gmatch("[^\r\n]+") do
                local area, map = line:match("^%s*%[(%d+)%]%s*=%s*(%d+)")
                if area then mapping[tonumber(area)] = tonumber(map) end
            end
        elseif type(value) == "table" then
            for area, map in pairs(value) do
                if IsFinite(area) and IsFinite(map) then mapping[area] = map end
            end
        end
    end
    cachedDB, cachedBase, cachedOverride, cachedMapping = db, base, override, mapping
    return mapping
end

local function ReadLocations(db, entity, id)
    local mapping, locations = AreaMapping(db), {}
    local spawns = entity.spawns(id) or {}
    local areas = {}
    for area in pairs(spawns) do if IsFinite(area) then areas[#areas + 1] = area end end
    table.sort(areas)
    local usable = 0
    for _, area in ipairs(areas) do
        for index, position in ipairs(spawns[area]) do
            local x, y = position[1], position[2]
            local mapID = mapping[area]
            local mapInfo = IsID(mapID) and C_Map.GetMapInfo(mapID) or nil
            local location = {
                areaID = area, spawnIndex = index, coordinateMapID = mapID,
                originalX = x, originalY = y, originalUnits = "percent",
                phase = position[3], source = "QuestieDB", available = false,
            }
            if x == -1 and y == -1 then
                location.reason, location.precision = "instance_only", "instance_area"
            elseif not IsFinite(x) or not IsFinite(y) or x < 0 or y < 0 or x > 100 or y > 100 then
                location.reason = "invalid_coordinates"
            elseif not mapID then
                location.reason = "map_mapping_missing"
            elseif mapID == 0 then
                location.reason = "map_suppressed"
            elseif not mapInfo then
                location.reason = "unsupported_map"
            else
                location.available, location.precision = true, "static_spawn"
                location.x, location.y, location.units = x / 100, y / 100, "normalized"
                location.mapName = mapInfo.name
                location.world = ToWorld(mapID, location.x, location.y)
                usable = usable + 1
            end
            locations[#locations + 1] = location
        end
    end
    return locations, usable
end

local function ReadDatabaseEntity(db, info, args, page)
    local entity = args.kind == "npc" and db.Npc or args.kind == "object" and db.Object or db.Item
    if not entity or not entity.Exists(args.id) then
        return { ok = true, schemaVersion = 1, available = false, source = "QuestieDB", reason = "entity_not_found", kind = args.kind, id = args.id }
    end
    local result = {
        ok = true, schemaVersion = 1, apiRevision = ns.apiRevision, available = true,
        source = "QuestieDB", version = info.version, contract = info.contract,
        kind = args.kind, id = args.id, name = entity.name(args.id),
    }
    if args.kind == "item" then
        local relations = {}
        local fields = {
            { "npcDrops", "npc", "drop" }, { "objectDrops", "object", "drop" },
            { "itemDrops", "item", "container" }, { "vendors", "npc", "vendor" },
        }
        for _, field in ipairs(fields) do
            for _, id in ipairs(entity[field[1]](args.id) or {}) do
                relations[#relations + 1] = { kind = field[2], id = id, relation = field[3] }
            end
        end
        result.startQuest = entity.startQuest(args.id)
        return AddPage(result, relations, page, "relations")
    end
    local locations, usable = ReadLocations(db, entity, args.id)
    result.usableLocationTotal = usable
    result.locationAvailability = #locations == 0 and "missing" or usable > 0 and "available" or "unusable"
    result.locationsOwner = db.GetProvenance and db.GetProvenance(args.kind == "npc" and "Npc" or "Object", args.id, "spawns")
    return AddPage(result, locations, page, "locations")
end

function ns.GetDatabaseEntity(args)
    if type(args) ~= "table" then return InvalidArguments("args must be an object") end
    if args.kind ~= "npc" and args.kind ~= "object" and args.kind ~= "item" then
        return InvalidArguments("kind must be npc, object or item")
    end
    if not IsID(args.id) then return InvalidArguments("id must be a positive integer") end
    local page, message = ParsePage(args)
    if not page then return InvalidArguments(message) end
    local db, info = GetDatabase()
    if not db then
        info.ok, info.schemaVersion = true, 1
        return info
    end
    local ok, result = pcall(ReadDatabaseEntity, db, info, args, page)
    if not ok then return { ok = false, error = { code = "database_error", message = tostring(result) } } end
    return result
end

local function ReadDatabaseQuest(db, info, questID, page)
    if not db.Quest.Exists(questID) then
        return { available = false, source = "QuestieDB", reason = "quest_not_found", version = info.version }
    end
    local references = {}
    local function AddReferences(groups, role, kinds)
        for index, kind in ipairs(kinds) do
            for _, id in ipairs(groups[index] or {}) do
                references[#references + 1] = { role = role, kind = kind, id = id }
            end
        end
    end
    AddReferences(db.Quest.startedBy(questID) or {}, "quest_start", { "npc", "object", "item" })
    AddReferences(db.Quest.finishedBy(questID) or {}, "quest_turn_in", { "npc", "object" })
    local objectives = db.Quest.objectives(questID) or {}
    for group, kind in ipairs({ "npc", "object", "item" }) do
        for index, row in ipairs(objectives[group] or {}) do
            references[#references + 1] = {
                role = "objective_reference", kind = kind, id = row[1],
                databaseGroup = group, databaseIndex = index,
                text = row[2], databaseExtra = row[3],
            }
        end
    end
    local result = {
        available = true, source = "QuestieDB", version = info.version, contract = info.contract,
        name = db.Quest.name(questID), questLevel = db.Quest.questLevel(questID),
        requiredLevel = db.Quest.requiredLevel(questID),
        objectivesText = db.Quest.objectivesText(questID),
        specialObjectiveRelations = {
            reputation = objectives[4], killCredit = objectives[5], spell = objectives[6],
        },
        chain = {
            preQuestSingle = db.Quest.preQuestSingle(questID), preQuestGroup = db.Quest.preQuestGroup(questID),
            childQuests = db.Quest.childQuests(questID), nextQuestInChain = db.Quest.nextQuestInChain(questID),
            exclusiveTo = db.Quest.exclusiveTo(questID),
        },
        objectiveIndexMapping = "not_inferred",
    }
    return AddPage(result, references, page, "references")
end

function ns.GetQuestDetails(args)
    if type(args) ~= "table" or not IsID(args.questID) then return InvalidArguments("questID must be a positive integer") end
    if args.allowDatabase ~= nil and type(args.allowDatabase) ~= "boolean" then return InvalidArguments("allowDatabase must be a boolean") end
    if args.includePOIs ~= nil and type(args.includePOIs) ~= "boolean" then return InvalidArguments("includePOIs must be a boolean") end
    local page, message = ParsePage(args)
    if not page then return InvalidArguments(message) end
    local active = ActiveQuestIndex()
    local entry = active[args.questID]
    local official = { available = entry ~= nil, source = "client", inLog = entry ~= nil }
    if entry then official.quest = ReadQuest(entry.info, entry.category, true) else official.reason = "quest_not_in_log" end
    if args.includePOIs ~= false then
        local pois, meta = CollectPOIs({ questID = args.questID }, active)
        official.pois, official.poiCoverage = pois, meta.mapScope
        official.poiRawCount = meta.rawCount
    end
    local database
    if args.allowDatabase == false then
        database = { available = false, source = "QuestieDB", reason = "disabled_by_request" }
    else
        local db, info = GetDatabase()
        database = info
        if db then
            local ok, supplemental = pcall(ReadDatabaseQuest, db, info, args.questID, page)
            if ok then database = supplemental else
                database = { available = false, source = "QuestieDB", reason = "database_error", message = tostring(supplemental) }
            end
        end
    end
    return {
        ok = true, schemaVersion = 1, apiRevision = ns.apiRevision, questID = args.questID,
        policy = "client_first", official = official, database = database,
    }
end

WB:Expose("get_player_context", ns.GetPlayerContext,
    "只读获取原生玩家等级、经验、地图位置和世界坐标。args:{}。不可用的位置给出reason；不读取生命/能量。")
WB:Expose("get_quest_pois", ns.GetQuestPOIs,
    "只读查询已接任务原生POI。args:可选mapID（只查该图）、questID、offset>=0、limit=1..100（默认50）。"
    .. "未给mapID时扫描艾泽拉斯地图树，去除同任务同位置的投影重复，保留coordinateMapID/reportedMapID和projectionCount；不保证副本覆盖。")
WB:Expose("get_quest_details", ns.GetQuestDetails,
    "原生任务状态、目标和POI为主，QuestieDB元数据/接交关系/任务链独立补充。args:questID必填，"
    .. "allowDatabase=true/false（默认true），includePOIs=true/false（默认true），offset/limit对数据库references分页（默认50/max100）。不推断逐目标序号对应或击杀行为。")
WB:Expose("get_database_entity", ns.GetDatabaseEntity,
    "只读查询QuestieDB实体。args:kind=npc/object/item、id，offset/limit（默认50/max100）。"
    .. "NPC/物件返回locations，物品返回掉落/容器/商人relations；坐标统一0..1，保留AreaID和百分比原值；副本哨兵/无效地图明确不可导航。数据库缺失时available=false。")

-- 简易升级路线：当前地图内按原生难度/奖励校准直线距离；只画自有地图图层。
local route = ns.route or { views = {}, sequence = 0 }
ns.route = route
local instanceTags = { [62] = true, [81] = true, [85] = true, [88] = true, [89] = true, [98] = true, [288] = true }
local professionCategories = {
    ["炼金术"] = true, ["锻造"] = true, ["附魔"] = true, ["工程学"] = true,
    ["草药学"] = true, ["制皮"] = true, ["采矿"] = true, ["剥皮"] = true,
    ["裁缝"] = true, ["钓鱼"] = true, ["烹饪"] = true, ["急救"] = true,
    ["珠宝加工"] = true, ["铭文"] = true, ["考古学"] = true,
}

local function RouteSettings()
    local name = Accessible(UnitName("player"))
    if not name then
        route.temporary = route.temporary or { skipped = {}, moveThreshold = 100, enabled = true }
        return route.temporary
    end
    YYQQuestAPIDB = YYQQuestAPIDB or {}
    YYQQuestAPIDB.routes = YYQQuestAPIDB.routes or {}
    local key = GetRealmName() .. ":" .. name
    local settings = YYQQuestAPIDB.routes[key]
    if not settings then
        settings = { skipped = {}, moveThreshold = 100, enabled = true }
        YYQQuestAPIDB.routes[key] = settings
    end
    return settings
end

local function DistanceSquared(a, b)
    if not a or not b or a.continentID ~= b.continentID then return nil end
    return (a.x - b.x) ^ 2 + (a.y - b.y) ^ 2
end

local function RouteExclusion(quest, db, settings)
    if settings.skipped[quest.questID] then return "skipped", "player" end
    if quest.isFailed then return "failed", "client" end
    local tag = quest.tag
    local questType = C_QuestLog.GetQuestType(quest.questID)
    if instanceTags[questType] or (tag and instanceTags[tag.id]) then return "instance", "client" end
    if C_QuestLog.IsEliteQuest(quest.questID) or (tag and tag.isElite) then return "elite", "client" end
    if (tag and IsID(tag.tradeskillLineID)) or professionCategories[quest.category] then
        return "profession", "client"
    end
    if db and db.Quest and type(db.Quest.requiredSkill) == "function" then
        local ok, skill = pcall(db.Quest.requiredSkill, quest.questID)
        if ok and type(skill) == "table" and IsID(skill[1]) then return "profession", "QuestieDB" end
    end
end

local difficultyBands = {
    [0] = { name = "trivial", weight = 0.4 }, [1] = { name = "easy", weight = 1.25 },
    [2] = { name = "fair", weight = 1 }, [3] = { name = "difficult", weight = 0.65 },
    [4] = { name = "impossible", weight = 0.4 },
}
local priorityLabels = {
    easy_with_reward = "难度较低，已有经验奖励", easy_experience_unknown = "难度较低，奖励经验未知",
    appropriate = "难度适中", difficulty_unknown = "难度未知，按距离安排",
    difficult = "难度较高，适当靠后", very_difficult = "难度很高，适当靠后",
    trivial_on_the_way = "任务已属琐碎，适合顺路完成", low_reward_on_the_way = "奖励经验较低，适合顺路完成",
    below_typical_reward = "奖励经验偏低", turn_in = "任务已完成，可安排交付",
    turn_in_on_the_way = "低收益任务，适合顺路交付", completion_pending = "任务已完成，等待确认交付信息",
}

local function SafePriorityRead(func, questID)
    if type(func) ~= "function" then return nil, "api_unavailable" end
    local ok, value = pcall(func, questID)
    if not ok then return nil, "read_error" end
    if not canaccessvalue(value) then return nil, "restricted" end
    if value == nil then return nil, "data_unavailable" end
    return value
end

local function ReadLevelingData(quest)
    local id = quest.questID
    local cached, cacheReason = SafePriorityRead(HaveQuestData, id)
    local data = {
        difficulty = { available = false, name = "unknown", source = "C_PlayerInfo.GetContentDifficultyQuestForPlayer" },
        experience = { available = false, source = "GetQuestLogRewardXP" },
    }
    if cached == false then
        data.difficulty.reason, data.experience.reason = "quest_data_not_ready", "quest_data_not_ready"
        return data
    end
    local code, difficultyReason = SafePriorityRead(C_PlayerInfo and C_PlayerInfo.GetContentDifficultyQuestForPlayer, id)
    local trivial = SafePriorityRead(C_QuestLog.IsQuestTrivial, id)
    if type(trivial) == "boolean" then data.difficulty.isTrivial = trivial end
    if trivial == true then code = 0; data.difficulty.source = "C_QuestLog.IsQuestTrivial" end
    if IsFinite(code) and difficultyBands[code] then
        data.difficulty.available, data.difficulty.code, data.difficulty.name = true, code, difficultyBands[code].name
    else
        data.difficulty.reason = difficultyReason or "invalid_difficulty"
    end
    -- 这三个旧读取函数已在本客户端实测：显式questID，不切换选中任务。
    -- 任务信息就绪不代表奖励就绪；缺少缓存证明时不把0经验当成真实收益。
    local rewards, rewardReason = SafePriorityRead(HaveQuestRewardData, id)
    if cached ~= true or rewards ~= true then
        data.experience.reason = cached ~= true and (cacheReason or "quest_cache_unknown")
            or rewardReason or "reward_data_not_ready"
        return data
    end
    local xp, xpReason = SafePriorityRead(GetQuestLogRewardXP, id)
    if IsFinite(xp) and xp >= 0 then
        data.experience.available, data.experience.value = true, xp
    else
        data.experience.reason = xpReason or "invalid_experience"
    end
    return data
end

local function RewardReference(candidates, levelXPMaximum)
    local values = {}
    for _, candidate in ipairs(candidates) do
        local data = candidate.priority
        local code = data.difficulty.code
        if (code == 1 or code == 2) and data.experience.available and data.experience.value > 0 then
            values[#values + 1] = data.experience.value
        end
    end
    table.sort(values)
    local reference = { sampleCount = #values, minimumSamples = 3, available = #values >= 3,
        scope = "current_map_eligible_easy_fair", method = "median_positive_native_reward",
        levelXPMaximum = IsFinite(levelXPMaximum) and levelXPMaximum > 0 and levelXPMaximum or nil }
    if reference.available then
        local middle = math.floor((#values + 1) / 2)
        reference.value = #values % 2 == 1 and values[middle] or values[middle] / 2 + values[middle + 1] / 2
    end
    return reference
end

local function ApplyLevelingPriority(candidate, reference)
    local data, quest = candidate.priority, candidate.quest
    local band = difficultyBands[data.difficulty.code]
    local completed = quest.readyForTurnIn or quest.isComplete
    data.difficultyWeight = completed and 1 or band and band.weight or 1
    local xp = data.experience
    local rewardWeight = 1
    if xp.available then
        if reference.available then xp.relativeToReference = xp.value / reference.value end
        if reference.levelXPMaximum then xp.fractionOfLevel = xp.value / reference.levelXPMaximum end
        if xp.value == 0 then rewardWeight = 0.5
        elseif (xp.relativeToReference and xp.relativeToReference < 0.25)
            or (xp.fractionOfLevel and xp.fractionOfLevel < 0.005) then rewardWeight = 0.55
        elseif (xp.relativeToReference and xp.relativeToReference < 0.5)
            or (xp.fractionOfLevel and xp.fractionOfLevel < 0.01) then rewardWeight = 0.8 end
    end
    data.lowReward = xp.available and (xp.value == 0
        or (xp.relativeToReference ~= nil and xp.relativeToReference < 0.25)
        or (xp.fractionOfLevel ~= nil and xp.fractionOfLevel < 0.005))
    data.experienceWeight = completed and math.max(0.85, rewardWeight) or rewardWeight
    if quest.isComplete and not quest.readyForTurnIn then data.reason = "completion_pending"
    elseif completed then
        data.reason = (data.lowReward or data.difficulty.code == 0) and "turn_in_on_the_way" or "turn_in"
    elseif data.difficulty.code == 0 then data.reason = "trivial_on_the_way"
    elseif data.lowReward then data.reason = "low_reward_on_the_way"
    elseif data.difficulty.code == 4 then data.reason = "very_difficult"
    elseif data.difficulty.code == 3 then data.reason = "difficult"
    elseif rewardWeight < 1 then data.reason = "below_typical_reward"
    elseif data.difficulty.code == 1 then data.reason = xp.available and "easy_with_reward" or "easy_experience_unknown"
    else data.reason = data.difficulty.available and "appropriate" or "difficulty_unknown" end
    data.weight = data.difficultyWeight * data.experienceWeight
    candidate.priorityWeight = data.weight
end

local routeRules = {
    groupRadius = 200, arrivalRadius = 120, progressRadius = 300, progressWindow = 90,
    switchRatio = 0.7, minSaving = 50, poiTolerance = 100,
}
route.progress = route.progress or {}

local function TrackProgress(quest, now)
    local previous = route.progress[quest.questID]
    if quest.status ~= "in_progress" then
        route.progress[quest.questID] = { status = quest.status }
        return
    end
    -- 暂未返回目标数据时保留上次快照，不把重新加载数据当成首次进度。
    if not quest.objectivesLoaded or #quest.objectives == 0 then return end
    local snapshot = { status = quest.status, objectives = {} }
    for i, objective in ipairs(quest.objectives) do
        local label = Accessible(objective.text)
        if type(label) == "string" then label = label:gsub("%d+%s*/%s*%d+", "#/#") else label = nil end
        snapshot.objectives[i] = {
            label = label, kind = Accessible(objective.type), required = IsFinite(objective.numRequired) and objective.numRequired or nil,
            value = IsFinite(objective.numFulfilled) and objective.numFulfilled or nil,
            finished = Accessible(objective.finished),
        }
    end
    local old = previous and previous.status == quest.status and previous.objectives
    if old and #old == #snapshot.objectives then
        local compatible, increased, regressed = true, false, false
        for i, current in ipairs(snapshot.objectives) do
            local prior = old[i]
            if current.kind ~= prior.kind or current.required ~= prior.required or current.label ~= prior.label then compatible = false end
            if current.value and prior.value then
                if current.value > prior.value then increased = true end
                if current.value < prior.value then regressed = true end
            end
            if current.finished == true and prior.finished == false then increased = true end
            if current.finished == false and prior.finished == true then regressed = true end
        end
        if compatible and not regressed then snapshot.lastProgressAt = increased and now or previous.lastProgressAt end
    end
    route.progress[quest.questID] = snapshot
end

local function ChooseCandidate(remaining, cursor, anchor, members)
    local bestIndex, bestPoint, bestDistance, bestScore
    for index, candidate in ipairs(remaining) do
        if not members or members[candidate.quest.questID] == candidate.quest.status then
            for _, point in ipairs(candidate.points) do
                local localDistance = anchor and DistanceSquared(anchor, point.world)
                if not anchor or (localDistance and localDistance <= routeRules.groupRadius ^ 2) then
                    local distance = DistanceSquared(cursor, point.world)
                    local score = distance and distance / (candidate.priorityWeight * candidate.priorityWeight)
                    if score and (not bestScore or score < bestScore
                        or (score == bestScore and (distance < bestDistance
                            or (distance == bestDistance and candidate.quest.questID < remaining[bestIndex].quest.questID)))) then
                        bestIndex, bestPoint, bestDistance, bestScore = index, point, distance, score
                    end
                end
            end
        end
    end
    return bestIndex, bestPoint, bestDistance, bestScore
end

local function StableFirst(remaining, origin, mapID, reason, now)
    local bestIndex, bestPoint, bestDistance, bestScore = ChooseCandidate(remaining, origin)
    local previous = route.plan
    local first = previous and previous.steps[1]
    local decision = { retained = false, reason = reason == "manual" and "manual_replan" or "nearest_weighted" }
    decision.previousQuestID = first and first.questID
    if not bestIndex or reason == "manual" or not first or previous.mapID ~= mapID then
        return bestIndex, bestPoint, bestDistance, bestScore, decision
    end
    local group = previous.groups and previous.groups[first.groupIndex]
    local previousIndex, previousPoint, previousShift
    for index, candidate in ipairs(remaining) do
        if candidate.quest.questID == first.questID and candidate.quest.status == first.status then
            for _, point in ipairs(candidate.points) do
                local shift = DistanceSquared(first.world, point.world)
                if shift and shift <= routeRules.poiTolerance ^ 2 and (not previousShift or shift < previousShift) then
                    previousIndex, previousPoint, previousShift = index, point, shift
                end
            end
        end
    end
    if previousIndex then
        local candidate = remaining[previousIndex]
        local distance = DistanceSquared(origin, previousPoint.world)
        local score = distance / (candidate.priorityWeight * candidate.priorityWeight)
        local oldWeighted, newWeighted = math.sqrt(score), math.sqrt(bestScore)
        local progress = route.progress[first.questID]
        local progressAge = progress and progress.lastProgressAt and now - progress.lastProgressAt
        local keepReason
        if first.status == "in_progress" and distance <= routeRules.arrivalRadius ^ 2 then
            keepReason = "at_objective_area"
        elseif first.status == "in_progress" and distance <= routeRules.progressRadius ^ 2
            and progressAge and progressAge >= 0 and progressAge <= routeRules.progressWindow then
            keepReason = "recent_objective_progress"
        elseif bestIndex == previousIndex and bestPoint == previousPoint then
            keepReason = "same_target"
        elseif newWeighted > oldWeighted * routeRules.switchRatio + 0.000001
            or oldWeighted - newWeighted < routeRules.minSaving - 0.000001 then
            keepReason = "avoid_small_switch"
        end
        if keepReason then
            decision.retained, decision.reason = true, keepReason
            decision.lastProgressAt = progress and progress.lastProgressAt
            local anchor = group and DistanceSquared(group.anchor, previousPoint.world)
            return previousIndex, previousPoint, distance, score, decision,
                anchor and anchor <= routeRules.groupRadius ^ 2 and group.anchor or nil
        end
        decision.reason = "clearly_better_candidate"
    elseif group then
        -- 原任务交付/完成/消失后，在仍身处原区域时接着做这一批剩余任务。
        local nearby = DistanceSquared(origin, group.anchor)
        if nearby and nearby <= routeRules.progressRadius ^ 2 then
            local members = {}
            for _, step in ipairs(previous.steps) do
                if step.groupIndex == first.groupIndex and step.questID ~= first.questID then members[step.questID] = step.status end
            end
            local index, point, distance, score = ChooseCandidate(remaining, origin, group.anchor, members)
            if index then
                decision.reason = "continue_nearby_group"
                return index, point, distance, score, decision, group.anchor
            end
        end
        decision.reason = "previous_target_changed"
    else
        decision.reason = "previous_target_changed"
    end
    return bestIndex, bestPoint, bestDistance, bestScore, decision
end

local function RebuildRoute(reason)
    local settings = RouteSettings()
    local context = ns.GetPlayerContext({})
    local origin = context.location
    local mapID = origin.coordinateMapID
    local now = GetTime()
    local active = ActiveQuestIndex()
    local pois = CollectPOIs({}, active)
    local db = GetDatabase()
    local byQuest, excluded, remaining = {}, {}, {}
    for _, poi in ipairs(pois) do
        byQuest[poi.questID] = byQuest[poi.questID] or {}
        byQuest[poi.questID][#byQuest[poi.questID] + 1] = poi
    end
    local ids = {}
    for id in pairs(active) do ids[#ids + 1] = id end
    table.sort(ids)
    for _, id in ipairs(ids) do
        local entry = active[id]
        local quest = ReadQuest(entry.info, entry.category, false)
        local objectivesOK, objectives = pcall(C_QuestLog.GetQuestObjectives, id)
        quest.objectivesLoaded = objectivesOK and type(objectives) == "table"
        quest.objectives = quest.objectivesLoaded and objectives or {}
        TrackProgress(quest, now)
        local why, source = RouteExclusion(quest, db, settings)
        local options, hasLocalPoint = {}, false
        if not why then
            for _, point in ipairs(byQuest[id] or {}) do
                -- 邻图也会返回本图内的投影，归属必须看reportedMapID，不能看坐标边界或查询图。
                if IsID(mapID) and point.reportedMapID == mapID then
                    hasLocalPoint = true
                    if origin.world and point.world and origin.world.continentID == point.world.continentID then
                        options[#options + 1] = point
                    end
                end
            end
            if #options == 0 then
                why = not IsID(mapID) and "player_map_unavailable"
                    or not byQuest[id] and "no_native_poi"
                    or not hasLocalPoint and "outside_current_map"
                    or not origin.world and "player_position_unavailable" or "world_position_unavailable"
                source = "client"
            end
        end
        if why then
            excluded[#excluded + 1] = { questID = id, title = quest.title, reason = why, source = source }
        else
            remaining[#remaining + 1] = {
                quest = quest, points = options, priority = ReadLevelingData(quest),
            }
        end
    end
    local rewardReference = RewardReference(remaining, context.experience.maximum)
    local pendingRewards = 0
    for _, candidate in ipairs(remaining) do
        ApplyLevelingPriority(candidate, rewardReference)
        local why = candidate.priority.experience.reason
        if why == "reward_data_not_ready" or why == "quest_data_not_ready" or why == "read_error" or why == "data_unavailable" then
            pendingRewards = pendingRewards + 1
        end
    end
    -- 奖励缓存可独立于任务信息就绪；只在仍有暂缺数据时轻量重试，避免依赖单一事件。
    route.nextRewardCheck = pendingRewards > 0 and now + 5 or nil
    route.activeQuestIDs = active
    for id in pairs(route.progress) do if not active[id] then route.progress[id] = nil end end
    local firstIndex, firstPoint, firstDistance, firstScore, stability, firstAnchor =
        StableFirst(remaining, origin.world, mapID, reason, now)
    local cursor, steps, groups, pathLength = origin.world, {}, {}, 0
    local group
    while cursor and #remaining > 0 do
        local bestIndex, bestPoint, bestDistance, bestScore
        if #steps == 0 then
            bestIndex, bestPoint, bestDistance, bestScore = firstIndex, firstPoint, firstDistance, firstScore
        elseif group then
            bestIndex, bestPoint, bestDistance, bestScore = ChooseCandidate(remaining, cursor, group.anchor)
        end
        if not bestIndex then
            bestIndex, bestPoint, bestDistance, bestScore = ChooseCandidate(remaining, cursor)
            group = nil
        end
        if not bestIndex then break end
        if not group then
            group = { index = #groups + 1, anchor = #steps == 0 and firstAnchor or bestPoint.world, questIDs = {}, count = 0 }
            if not group.anchor then group.anchor = bestPoint.world end
            groups[#groups + 1] = group
        end
        local selected = table.remove(remaining, bestIndex)
        local quest = selected.quest
        local distance = math.sqrt(bestDistance)
        pathLength = pathLength + distance
        group.count = group.count + 1
        group.questIDs[#group.questIDs + 1] = quest.questID
        steps[#steps + 1] = {
            index = #steps + 1, questID = quest.questID, title = quest.title, level = quest.level,
            status = quest.status, action = quest.readyForTurnIn and "turn_in" or quest.isComplete and "completion_pending" or "quest_area",
            groupIndex = group.index, targetMapID = bestPoint.reportedMapID,
            coordinateMapID = bestPoint.coordinateMapID, x = bestPoint.x, y = bestPoint.y,
            world = bestPoint.world, source = bestPoint.source, precision = bestPoint.precision,
            segmentDistance = distance, priorityWeight = selected.priorityWeight, weightedDistance = math.sqrt(bestScore),
            priority = selected.priority,
        }
        cursor = bestPoint.world
    end
    for _, step in ipairs(steps) do step.groupSize = groups[step.groupIndex].count end
    stability.questID = steps[1] and steps[1].questID
    route.sequence = route.sequence + 1
    route.plan = {
        ok = true, schemaVersion = 1, apiRevision = ns.apiRevision, sequence = route.sequence,
        policy = "stable_grouped_leveling_straight_line", scope = "current_player_map_active_quests",
        groups = groups, groupRadius = routeRules.groupRadius, stability = stability,
        mapID = mapID, mapName = origin.mapName,
        levelPriority = { referenceLevel = context.character.level, perLevelBonus = 0, maxWeight = 1.25,
            method = "client_difficulty_and_reward" },
        levelingPriority = { source = "client", reference = rewardReference,
            difficultyWeights = { trivial = 0.4, easy = 1.25, fair = 1, difficult = 0.65, impossible = 0.4 },
            rewardThresholds = { veryLowRatio = 0.25, lowRatio = 0.5, veryLowLevelFraction = 0.005, lowLevelFraction = 0.01 },
            pendingRewardCount = pendingRewards, rewardRetrySeconds = 5, unknownWeight = 1,
            turnInMinimumExperienceWeight = 0.85 },
        origin = origin, count = #steps, steps = steps, excluded = excluded,
        moveThreshold = settings.moveThreshold, enabled = settings.enabled,
        totalStraightDistance = pathLength, reason = reason, plannedAt = now,
    }
    route.playerLocation, route.lastOrigin = origin, origin.world
    route.dirty, route.pendingReason = false, nil
    WB:Emit("route.updated", { sequence = route.sequence, mapID = mapID, count = #steps, reason = reason })
    return route.plan
end

function ns.GetPlan(args)
    if args ~= nil and type(args) ~= "table" then return InvalidArguments("args must be an object") end
    return route.plan or RebuildRoute("requested")
end

function ns.Replan(args)
    if args ~= nil and type(args) ~= "table" then return InvalidArguments("args must be an object") end
    return RebuildRoute("manual")
end

function ns.SetQuestSkip(args)
    if type(args) ~= "table" or not IsID(args.questID) then return InvalidArguments("questID must be a positive integer") end
    if args.skipped ~= nil and type(args.skipped) ~= "boolean" then return InvalidArguments("skipped must be a boolean") end
    local settings = RouteSettings()
    local skipped = args.skipped ~= false
    settings.skipped[args.questID] = skipped or nil
    RebuildRoute(skipped and "quest_skipped" or "quest_restored")
    return { ok = true, questID = args.questID, skipped = skipped, count = route.plan.count }
end

function ns.ResetQuestSkips(args)
    if args ~= nil and type(args) ~= "table" then return InvalidArguments("args must be an object") end
    RouteSettings().skipped = {}
    return RebuildRoute("skips_reset")
end

function ns.SetRouteOptions(args)
    if type(args) ~= "table" then return InvalidArguments("args must be an object") end
    if args.enabled ~= nil and type(args.enabled) ~= "boolean" then return InvalidArguments("enabled must be a boolean") end
    if args.moveThreshold ~= nil and (not IsFinite(args.moveThreshold) or args.moveThreshold < 10 or args.moveThreshold > 5000) then
        return InvalidArguments("moveThreshold must be from 10 to 5000")
    end
    local settings = RouteSettings()
    if args.enabled ~= nil then settings.enabled = args.enabled end
    if args.moveThreshold ~= nil then settings.moveThreshold = args.moveThreshold end
    return RebuildRoute("options_changed")
end

-- 纯几何裁剪，不把地图外的线段连成一条虚假的地图内路线。
local function ClipSegment(ax, ay, bx, by)
    local dx, dy, low, high = bx - ax, by - ay, 0, 1
    local p, q = { -dx, dx, -dy, dy }, { ax, 1 - ax, ay, 1 - ay }
    for i = 1, 4 do
        if p[i] == 0 then
            if q[i] < 0 then return nil end
        else
            local value = q[i] / p[i]
            if p[i] < 0 then low = math.max(low, value) else high = math.min(high, value) end
            if low > high then return nil end
        end
    end
    return ax + low * dx, ay + low * dy, ax + high * dx, ay + high * dy
end

local function ProjectWorld(world, mapID)
    if not world then return nil end
    local ok, actualMap, point = pcall(C_Map.GetMapPosFromWorldPos,
        world.continentID, CreateVector2D(world.x, world.y), mapID)
    if ok and actualMap == mapID and point and IsFinite(point.x) and IsFinite(point.y) then
        return { x = point.x, y = point.y }
    end
end

local function NewMapView(map, canvas)
    local overlay = CreateFrame("Frame", nil, canvas)
    overlay:SetAllPoints(canvas)
    overlay:SetFrameLevel(canvas:GetFrameLevel() + 3000)
    overlay:EnableMouse(false)
    local view = { map = map, canvas = canvas, overlay = overlay, pins = {}, lines = {} }
    route.views[#route.views + 1] = view
    return view
end

local function ConfigureRoutePin(pin)
    pin:SetScript("OnClick", function(self)
        if self.step then
            ns.SetQuestSkip({ questID = self.step.questID })
            GameTooltip:Hide()
        end
    end)
    pin:SetScript("OnEnter", function(self)
        if not self.step then return end
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:SetText(self.step.index .. ". " .. self.step.title)
        GameTooltip:AddLine(self.step.action == "turn_in" and "前往交付任务"
            or self.step.action == "completion_pending" and "任务已完成，请确认交付信息" or "前往任务区域", 1, 0.85, 0.3)
        local priority = self.step.priority
        if priority then
            GameTooltip:AddLine(priorityLabels[priority.reason] or "按距离安排", 0.8, 0.9, 0.7)
            GameTooltip:AddLine(priority.experience.available and ("客户端奖励经验：" .. priority.experience.value)
                or "奖励经验尚未知", 0.75, 0.85, 1)
        end
        if self.step.groupSize and self.step.groupSize > 1 then
            GameTooltip:AddLine("同一区域，附近还有 " .. (self.step.groupSize - 1) .. " 个任务", 0.5, 1, 0.75)
            local shown = 0
            for _, step in ipairs(route.plan.steps) do
                if step.groupIndex == self.step.groupIndex and step.questID ~= self.step.questID then
                    GameTooltip:AddLine(step.index .. ". " .. step.title, 0.75, 0.9, 0.85)
                    shown = shown + 1
                    if shown == 3 then break end
                end
            end
        end
        if self.step.index == 1 and route.plan.stability and route.plan.stability.retained then
            GameTooltip:AddLine("继续当前目标；可用 /yyqroute replan 重新选择", 0.7, 0.85, 1)
        end
        if self.onEdge then GameTooltip:AddLine("目标在小地图视野外，边缘编号指示方向", 1, 0.7, 0.2) end
        GameTooltip:AddLine("右键跳过 · /yyqroute unskip " .. self.step.questID .. " 恢复", 0.6, 0.9, 1)
        GameTooltip:Show()
    end)
    pin:SetScript("OnLeave", function() GameTooltip:Hide() end)
end

local function NewRoutePin(view)
    local pin = CreateFrame("Button", nil, view.overlay)
    pin:SetSize(24, 24)
    pin:RegisterForClicks("RightButtonUp")
    pin.background = pin:CreateTexture(nil, "BACKGROUND")
    pin.background:SetAllPoints(pin)
    pin.background:SetColorTexture(0.08, 0.12, 0.15, 0.95)
    pin.color = pin:CreateTexture(nil, "ARTWORK")
    pin.color:SetPoint("TOPLEFT", pin, "TOPLEFT", 2, -2)
    pin.color:SetPoint("BOTTOMRIGHT", pin, "BOTTOMRIGHT", -2, 2)
    pin.text = pin:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    pin.text:SetAllPoints(pin)
    pin.text:SetTextColor(1, 1, 1)
    ConfigureRoutePin(pin)
    return pin
end

local function RenderMap(view, plan, player)
    if not view.map:IsShown() or not plan.enabled then view.overlay:Hide(); return end
    local mapID = view.map.GetMapID and view.map:GetMapID()
    local width, height = view.canvas:GetWidth(), view.canvas:GetHeight()
    if not IsID(mapID) or mapID ~= plan.mapID or not IsFinite(width) or not IsFinite(height) or width <= 0 or height <= 0 then
        view.overlay:Hide(); return
    end
    if view.sequence ~= plan.sequence or view.mapID ~= mapID then
        view.positions = {}
        for index, step in ipairs(plan.steps) do view.positions[index] = ProjectWorld(step.world, mapID) end
        view.sequence, view.mapID = plan.sequence, mapID
    end
    view.overlay:SetFrameLevel(view.canvas:GetFrameLevel() + 3000)
    view.overlay:Show()
    local scale = view.canvas:GetScale()
    if not IsFinite(scale) or scale <= 0 then scale = 1 end
    local previous = player and ProjectWorld(player.world, mapID)
    for index, step in ipairs(plan.steps) do
        local position = view.positions[index]
        local pin = view.pins[index]
        if position and position.x >= 0 and position.x <= 1 and position.y >= 0 and position.y <= 1 then
            if not pin then pin = NewRoutePin(view); view.pins[index] = pin end
            pin.step = step
            pin:SetScale(1 / scale)
            pin:ClearAllPoints()
            -- SetPoint 偏移按标记自身缩放解释，抵消逆缩放后仍须与地图线端点重合。
            pin:SetPoint("CENTER", view.overlay, "TOPLEFT", position.x * width * scale, -position.y * height * scale)
            pin.color:SetColorTexture(index == 1 and 0.95 or 0.05, index == 1 and 0.55 or 0.6, index == 1 and 0.05 or 0.75, 0.95)
            pin.text:SetText(index)
            pin:Show()
        elseif pin then pin:Hide() end
        local line = view.lines[index]
        local ax, ay, bx, by
        if previous and position then ax, ay, bx, by = ClipSegment(previous.x, previous.y, position.x, position.y) end
        if ax then
            if not line then
                line = view.overlay:CreateLine(nil, "ARTWORK")
                line:SetColorTexture(0.1, 0.85, 1, 0.8)
                view.lines[index] = line
            end
            line:SetThickness(2 / scale)
            line:SetStartPoint("TOPLEFT", view.overlay, ax * width, -ay * height)
            line:SetEndPoint("TOPLEFT", view.overlay, bx * width, -by * height)
            line:Show()
        elseif line then line:Hide() end
        previous = position
    end
    for i, pin in pairs(view.pins) do if i > #plan.steps then pin:Hide() end end
    for i, line in pairs(view.lines) do if i > #plan.steps then line:Hide() end end
end

local function RenderRouteMaps()
    local plan = route.plan
    if not plan then return end
    for _, map in pairs({ WorldMapFrame = WorldMapFrame, BattlefieldMapFrame = BattlefieldMapFrame }) do
        if map and map.GetCanvas and map.GetMapID then
            local canvas = map:GetCanvas()
            if canvas then
                local found
                for _, view in ipairs(route.views) do if view.map == map and view.canvas == canvas then found = view; break end end
                if not found then found = NewMapView(map, canvas) end
                RenderMap(found, plan, route.playerLocation)
            end
        end
    end
end

-- 小地图以玩家为中心，世界x向北、y向西；视野半径直接取客户端API。
local function MinimapPosition(world, origin, radius, cosine, sine)
    if not world or world.continentID ~= origin.continentID then return nil end
    local east, north = (origin.y - world.y) / radius, (world.x - origin.x) / radius
    return { x = east * cosine + north * sine, y = north * cosine - east * sine }
end

local function ClipMinimapSegment(ax, ay, bx, by, radius)
    local dx, dy = bx - ax, by - ay
    local a = dx * dx + dy * dy
    if a == 0 then return nil end
    local b, c = ax * dx + ay * dy, ax * ax + ay * ay - radius * radius
    local discriminant = b * b - a * c
    if discriminant < 0 then return nil end
    local root = math.sqrt(discriminant)
    local low, high = math.max(0, (-b - root) / a), math.min(1, (-b + root) / a)
    if low >= high then return nil end
    return ax + low * dx, ay + low * dy, ax + high * dx, ay + high * dy
end

local function RenderMinimapRoute()
    if not Minimap then return end
    local view = route.minimapView
    local plan, player = route.plan, route.playerLocation
    if not plan or not plan.enabled or not Minimap:IsVisible() or not player or not player.world
        or player.coordinateMapID ~= plan.mapID or #plan.steps == 0 then
        if view then view.overlay:Hide() end
        return
    end
    local radius = C_Minimap.GetViewRadius()
    local width, height = Minimap:GetWidth(), Minimap:GetHeight()
    local rotating, ignored = C_CVar.GetCVarBool("rotateMinimap"), C_Minimap.IsRotateMinimapIgnored()
    local cosine, sine = 1, 0
    if canaccessvalue(rotating) and rotating and canaccessvalue(ignored) and not ignored then
        local facing = GetPlayerFacing()
        if not IsFinite(facing) then if view then view.overlay:Hide() end; return end
        cosine, sine = math.cos(facing), math.sin(facing)
    end
    if not IsFinite(radius) or radius <= 0 or not IsFinite(width) or not IsFinite(height) or width <= 0 or height <= 0 then
        if view then view.overlay:Hide() end
        return
    end
    if not view then
        local overlay = CreateFrame("Frame", nil, Minimap)
        overlay:SetAllPoints(Minimap)
        overlay:EnableMouse(false)
        view = { overlay = overlay, pins = {}, lines = {} }
        route.minimapView = view
    end
    view.overlay:SetFrameLevel(Minimap:GetFrameLevel() + 5)
    view.overlay:Show()
    for _, pin in pairs(view.pins) do pin:Hide() end
    for _, line in pairs(view.lines) do line:Hide() end
    local previous = { x = 0, y = 0 }
    for index, step in ipairs(plan.steps) do
        local position = MinimapPosition(step.world, player.world, radius, cosine, sine)
        if position then
            local length = math.sqrt(position.x * position.x + position.y * position.y)
            local onEdge = length > 0.84
            if not onEdge or index == 1 then
                local x, y = position.x, position.y
                if onEdge then x, y = x * 0.84 / length, y * 0.84 / length end
                local pin = view.pins[index]
                if not pin then pin = NewRoutePin(view); pin:SetSize(20, 20); view.pins[index] = pin end
                pin.step, pin.onEdge = step, onEdge
                pin:ClearAllPoints()
                pin:SetPoint("CENTER", view.overlay, "CENTER", x * width / 2, y * height / 2)
                pin.color:SetColorTexture(index == 1 and 0.95 or 0.05, index == 1 and 0.55 or 0.6, index == 1 and 0.05 or 0.75, 0.95)
                pin.text:SetText(index)
                pin:Show()
            end
        end
        -- 裁剪实际端点，不连接边缘方向标记，以免画出不真实的后续路线。
        if previous and position then
            local ax, ay, bx, by = ClipMinimapSegment(previous.x, previous.y, position.x, position.y, 0.9)
            if ax then
                -- 第一段在玩家箭头旁留空，保留中心角色标记可见性。
                if index == 1 then
                    local length = math.sqrt(bx * bx + by * by)
                    if length > 0.07 then ax, ay = bx * 0.07 / length, by * 0.07 / length else ax = nil end
                end
                if ax then
                    local line = view.lines[index]
                    if not line then line = view.overlay:CreateLine(nil, "ARTWORK"); view.lines[index] = line end
                    line:SetColorTexture(index == 1 and 1 or 0.1, index == 1 and 0.65 or 0.85, index == 1 and 0.1 or 1, 0.9)
                    line:SetThickness(2.5)
                    line:SetStartPoint("CENTER", view.overlay, ax * width / 2, ay * height / 2)
                    line:SetEndPoint("CENTER", view.overlay, bx * width / 2, by * height / 2)
                    line:Show()
                end
            end
        end
        previous = position
    end
end

local function RouteTick(_, elapsed)
    route.elapsed = (route.elapsed or 0) + elapsed
    if route.elapsed < 0.1 then return end
    route.elapsed = 0
    local now = GetTime()
    if route.dirty and now >= (route.due or 0) then RebuildRoute(route.pendingReason or "quest_update") end
    if route.nextRewardCheck and now >= route.nextRewardCheck then RebuildRoute("reward_cache_refresh") end
    if now >= (route.nextPositionCheck or 0) then
        route.nextPositionCheck = now + 0.5
        local context = ns.GetPlayerContext({})
        route.playerLocation = context.location
        local current = route.playerLocation.world
        local distance = DistanceSquared(current, route.lastOrigin)
        local threshold = RouteSettings().moveThreshold
        if route.playerLocation.coordinateMapID ~= route.plan.mapID then
            RebuildRoute("player_map_changed")
        elseif context.character.level ~= route.plan.levelPriority.referenceLevel then
            RebuildRoute("player_level_changed")
        elseif current and (not route.lastOrigin or not distance or distance >= threshold * threshold) then
            RebuildRoute("player_moved")
        end
    end
    RenderRouteMaps()
    RenderMinimapRoute()
end

function ns.StartRoute()
    if not IsLoggedIn() or route.running then return end
    route.running = true
    RebuildRoute("startup")
    -- 复用图元时也更新回调，保证热加载后悬停说明使用本轮逻辑。
    for _, view in ipairs(route.views) do for _, pin in pairs(view.pins) do ConfigureRoutePin(pin) end end
    if route.minimapView then for _, pin in pairs(route.minimapView.pins) do ConfigureRoutePin(pin) end end
    local driver = route.driver or CreateFrame("Frame")
    route.driver = driver
    driver:UnregisterAllEvents()
    driver:RegisterEvent("QUEST_LOG_UPDATE")
    driver:RegisterEvent("PLAYER_ENTERING_WORLD")
    driver:RegisterEvent("ZONE_CHANGED_NEW_AREA")
    driver:RegisterEvent("QUEST_DATA_LOAD_RESULT")
    driver:SetScript("OnEvent", function(_, event, questID)
        if event == "QUEST_DATA_LOAD_RESULT" and not (route.activeQuestIDs and route.activeQuestIDs[questID]) then return end
        if not route.dirty then route.due = GetTime() + 0.5 end
        route.dirty, route.pendingReason = true, event
    end)
    driver:SetScript("OnUpdate", RouteTick)
    driver:Show()
    RenderRouteMaps()
    RenderMinimapRoute()
end

SLASH_YYQROUTE1 = "/yyqroute"
SlashCmdList["YYQROUTE"] = function(text)
    local command, value = (text or ""):match("^(%S*)%s*(.-)%s*$")
    local result
    if command == "skip" then result = ns.SetQuestSkip({ questID = tonumber(value) })
    elseif command == "unskip" then
        result = value == "all" and ns.ResetQuestSkips({}) or ns.SetQuestSkip({ questID = tonumber(value), skipped = false })
    elseif command == "distance" then result = ns.SetRouteOptions({ moveThreshold = tonumber(value) or false })
    elseif command == "on" or command == "off" then result = ns.SetRouteOptions({ enabled = command == "on" })
    elseif command == "replan" then result = ns.Replan({})
    else
        local plan = ns.GetPlan({})
        print("|cff31cee8YYQ升级路线|r " .. plan.count .. " 个任务，移动 " .. plan.moveThreshold .. " 码重排；地图右键编号跳过。")
        print("/yyqroute skip ID · unskip ID/all · distance 100 · replan · on/off")
        return
    end
    if result.ok then print("|cff31cee8YYQ升级路线|r 已更新路线。") else print(result.error.message) end
end

WB:Expose("get_plan", ns.GetPlan, "获取当前地图适合升级的直线任务路线。按原生难度/奖励校准距离，容易且正常收益略优先，困难/琐碎/低收益靠后；待交无战斗难度惩罚，未知数据不算零。保留过滤、200码归组与目标稳定，steps.priority含来源/原因，levelingPriority含经验参照。args:{}。")
WB:Expose("replan", ns.Replan, "主动按当前位置重新选1号并归组，绕过目标保持。采用原生难度/奖励校准的直线距离，不放弃或选择任务。args:{}。")
WB:Expose("set_quest_skip", ns.SetQuestSkip, "标注自己的路线跳过任务，不放弃任务。args:questID，skipped默认true；false恢复。按角色保存。")
WB:Expose("reset_quest_skips", ns.ResetQuestSkips, "恢复当前角色所有手动跳过的任务。args:{}。")
WB:Expose("set_route_options", ns.SetRouteOptions, "自己的路线选项。args:可选moveThreshold=10..5000（默认100码）、enabled=true/false同时控制大地图和小地图路线。")

function ns.OnUnload()
    route.running = false
    if route.driver then route.driver:UnregisterAllEvents(); route.driver:SetScript("OnUpdate", nil); route.driver:SetScript("OnEvent", nil) end
    if ns.loginFrame then ns.loginFrame:UnregisterAllEvents() end
    for _, view in ipairs(route.views) do
        view.overlay:Hide()
        view.sequence = nil
        for _, pin in pairs(view.pins) do pin:Hide(); pin.step = nil end
        for _, line in pairs(view.lines) do line:Hide() end
    end
    if route.minimapView then
        local view = route.minimapView
        view.overlay:Hide()
        for _, pin in pairs(view.pins) do pin:Hide(); pin.step = nil end
        for _, line in pairs(view.lines) do line:Hide() end
    end
end

function ns.OnReload()
    ns.StartRoute()
    WB:Emit("api.ready", { schemaVersion = 1, apiRevision = ns.apiRevision })
end

-- 正常登录与热加载共用初始化，不依赖在热加载中重发登录事件。
ns.loginFrame = ns.loginFrame or CreateFrame("Frame")
ns.loginFrame:UnregisterAllEvents()
ns.loginFrame:RegisterEvent("PLAYER_LOGIN")
ns.loginFrame:SetScript("OnEvent", function() ns.StartRoute() end)
if IsLoggedIn() then ns.StartRoute() end
